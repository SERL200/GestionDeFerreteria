namespace WindowsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTN_Admin = new System.Windows.Forms.Button();
            this.BTN_Tienda = new System.Windows.Forms.Button();
            this.BTN_Consulta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BTN_Admin
            // 
            this.BTN_Admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Admin.Location = new System.Drawing.Point(203, 12);
            this.BTN_Admin.Name = "BTN_Admin";
            this.BTN_Admin.Size = new System.Drawing.Size(182, 247);
            this.BTN_Admin.TabIndex = 1;
            this.BTN_Admin.Text = "Administraci�n";
            this.BTN_Admin.UseVisualStyleBackColor = true;
            this.BTN_Admin.Click += new System.EventHandler(this.BTN_Admin_Click);
            // 
            // BTN_Tienda
            // 
            this.BTN_Tienda.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Tienda.Location = new System.Drawing.Point(12, 12);
            this.BTN_Tienda.Name = "BTN_Tienda";
            this.BTN_Tienda.Size = new System.Drawing.Size(185, 247);
            this.BTN_Tienda.TabIndex = 2;
            this.BTN_Tienda.Text = "Tienda";
            this.BTN_Tienda.UseVisualStyleBackColor = true;
            this.BTN_Tienda.Click += new System.EventHandler(this.BTN_Tienda_Click);
            // 
            // BTN_Consulta
            // 
            this.BTN_Consulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Consulta.Location = new System.Drawing.Point(391, 12);
            this.BTN_Consulta.Name = "BTN_Consulta";
            this.BTN_Consulta.Size = new System.Drawing.Size(180, 247);
            this.BTN_Consulta.TabIndex = 3;
            this.BTN_Consulta.Text = "Consulta";
            this.BTN_Consulta.UseVisualStyleBackColor = true;
            this.BTN_Consulta.Click += new System.EventHandler(this.BTN_Consulta_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 266);
            this.Controls.Add(this.BTN_Consulta);
            this.Controls.Add(this.BTN_Tienda);
            this.Controls.Add(this.BTN_Admin);
            this.Name = "Form1";
            this.Text = "Menu Principal";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTN_Admin;
        private System.Windows.Forms.Button BTN_Tienda;
        private System.Windows.Forms.Button BTN_Consulta;
    }
}

