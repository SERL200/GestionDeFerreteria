using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsApplication1
{
    public partial class Consultas : Form
    {
        public Consultas()
        {
            InitializeComponent();
        }
        
        int eleccion = 0;
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\BD Ferreter�a.mdb");
        //Utilizar el de abajo (cambiar ruta)
        //OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Samuel\Desktop\Proyecto Ferreteria\GestionDeFerreteria\GestionDeFerreteria\BD Ferreter�a.mdb");
        public void consultaclientes()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Tabla_Clientes";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tabla.DataSource = dt;
            con.Close();
            
        }
        public void consultaproductos()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT TablaProductos.ID_Producto, TablaProductos.[ID Distribuidor], TablaProductos.Producto, TablaProductos.Precio, TablaProductos.Existencias, TablaDistribuidores.Distribuidor FROM TablaDistribuidores INNER JOIN TablaProductos ON TablaDistribuidores.ID_Distribuidor = TablaProductos.[ID Distribuidor]";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tabla.DataSource = dt;
            con.Close();
        }
        public void consultatrabajadores()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT TablaTrabajadores.ID_Trabajador, TablaTrabajadores.Trabajador, TablaTrabajadores.ID_Rol, TablaRoles.Rol FROM TablaRoles INNER JOIN TablaTrabajadores ON TablaRoles.ID_Rol = TablaTrabajadores.ID_Rol";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tabla.DataSource = dt;
            con.Close();
        }
        public void consultafacturas()
        {
            eleccion = 4;
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM TablaVentas";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tabla.DataSource = dt;
            con.Close();
        }
        public void busquedaproductos() { 
                        con.Open();
                        OleDbCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "SELECT TablaProductos.ID_Producto, TablaProductos.[ID Distribuidor], TablaProductos.Producto, TablaProductos.Precio, TablaProductos.Existencias, TablaDistribuidores.Distribuidor FROM TablaDistribuidores INNER JOIN TablaProductos ON TablaDistribuidores.ID_Distribuidor = TablaProductos.[ID Distribuidor] where TablaProductos.Producto LIKE '" + busqueda.Text + "%'";
                        cmd.ExecuteNonQuery();
                        DataTable dt = new DataTable();
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        da.Fill(dt);
                        tabla.DataSource = dt;
                        con.Close();
        }
        public void busquedatrabajadores() {
                        con.Open();
                        OleDbCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "SELECT TablaTrabajadores.ID_Trabajador, TablaTrabajadores.Trabajador, TablaTrabajadores.ID_Rol, TablaRoles.Rol FROM TablaRoles INNER JOIN TablaTrabajadores ON TablaRoles.ID_Rol = TablaTrabajadores.ID_Rol where TablaTrabajadores.Trabajador LIKE '" + busqueda.Text + "%'";
                        DataTable dt = new DataTable();
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        da.Fill(dt);
                        tabla.DataSource = dt;
                        con.Close();
        }
        public void busquedaclientes(){
                        con.Open();
                        OleDbCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "select * from Tabla_Clientes where ID_Cliente LIKE '" + busqueda.Text + "%'";
                        cmd.ExecuteNonQuery();
                        DataTable dt = new DataTable();
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        da.Fill(dt);
                        tabla.DataSource = dt;
                        con.Close();
        }
        public void busquedafacturas() {
            eleccion = 4;
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM TablaVentas where ID_Factura LIKE '" + busqueda.Text + "%'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tabla.DataSource = dt;
            con.Close();
        }
        
        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            productosToolStripMenuItem.Enabled = false;
            trabajadoresToolStripMenuItem.Enabled = true;
            clientesToolStripMenuItem.Enabled = true;
            distribuidoresToolStripMenuItem.Enabled = true;
            productosToolStripMenuItem.BackColor = Color.SeaShell;
            trabajadoresToolStripMenuItem.BackColor = Color.PeachPuff;
            clientesToolStripMenuItem.BackColor = Color.PeachPuff;
            distribuidoresToolStripMenuItem.BackColor = Color.PeachPuff;
            consultaproductos();
            eleccion = 1;
        }

        private void trabajadoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            productosToolStripMenuItem.Enabled = true;
            trabajadoresToolStripMenuItem.Enabled = false;
            clientesToolStripMenuItem.Enabled = true;
            distribuidoresToolStripMenuItem.Enabled = true;
            productosToolStripMenuItem.BackColor = Color.PeachPuff;
            trabajadoresToolStripMenuItem.BackColor = Color.SeaShell;
            clientesToolStripMenuItem.BackColor = Color.PeachPuff;
            distribuidoresToolStripMenuItem.BackColor = Color.PeachPuff;
            consultatrabajadores();
            eleccion = 2;
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            productosToolStripMenuItem.Enabled = true;
            trabajadoresToolStripMenuItem.Enabled = true;
            clientesToolStripMenuItem.Enabled = false;
            distribuidoresToolStripMenuItem.Enabled = true;
            productosToolStripMenuItem.BackColor = Color.PeachPuff;
            trabajadoresToolStripMenuItem.BackColor = Color.PeachPuff;
            clientesToolStripMenuItem.BackColor = Color.SeaShell;
            distribuidoresToolStripMenuItem.BackColor = Color.PeachPuff;
            consultaclientes();
            eleccion = 3;
        }

        private void distribuidoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            productosToolStripMenuItem.Enabled = true;
            trabajadoresToolStripMenuItem.Enabled = true;
            clientesToolStripMenuItem.Enabled = true;
            distribuidoresToolStripMenuItem.Enabled = false;
            productosToolStripMenuItem.BackColor = Color.PeachPuff;
            trabajadoresToolStripMenuItem.BackColor = Color.PeachPuff;
            clientesToolStripMenuItem.BackColor = Color.PeachPuff;
            distribuidoresToolStripMenuItem.BackColor = Color.SeaShell;
            consultafacturas();
            eleccion = 4;
        }

        private void busqueda_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (busqueda.Text == "")
            { MessageBox.Show("El campo de b�squeda esta vacio"); }
            else
            {
                try
                {
                    switch (eleccion)
                    {
                        case 1:
                            busquedaproductos();
                            break;
                        case 2:
                            busquedatrabajadores();
                            break;
                        case 3:
                            busquedaclientes();
                            break;
                        case 4:
                            busquedafacturas();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Elemento no encontrado, " + ex.Message);
                    con.Close();
                }

            }
                
        }

        private void Pic_Actualizar_Click(object sender, EventArgs e)
        {
            try
            {
                switch (eleccion)
                {
                    case 1:
                        consultaproductos();
                        break;
                    case 2:
                        consultatrabajadores();
                        break;
                    case 3:
                        consultaclientes();
                        break;
                    case 4:
                        consultafacturas();
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Elemento no encontrado, " + ex.Message);
                con.Close();
            }



        }

        private void productosToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            productosToolStripMenuItem.BackColor = Color.DarkSalmon;
        }

        private void trabajadoresToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            trabajadoresToolStripMenuItem.BackColor = Color.DarkSalmon;
        }

        private void clientesToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            clientesToolStripMenuItem.BackColor = Color.DarkSalmon;
        }

        private void distribuidoresToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            distribuidoresToolStripMenuItem.BackColor = Color.DarkSalmon;
        }

        private void Pic_Salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Pic_Minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        

        private void productosToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            productosToolStripMenuItem.BackColor = Color.PeachPuff;
          
        }

        private void trabajadoresToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            
            trabajadoresToolStripMenuItem.BackColor = Color.PeachPuff;
       
        }

        private void clientesToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            
            clientesToolStripMenuItem.BackColor = Color.PeachPuff;
 
        }

        private void distribuidoresToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            
            distribuidoresToolStripMenuItem.BackColor = Color.PeachPuff;
        }

        private void Pic_Actualizar_MouseEnter(object sender, EventArgs e)
        {
            Pic_Actualizar.BackColor = Color.Aquamarine;
        }

        private void Pic_Salir_MouseEnter(object sender, EventArgs e)
        {
            Pic_Salir.BackColor = Color.Red;
        }

        private void Pic_Minimizar_MouseEnter(object sender, EventArgs e)
        {
            Pic_Minimizar.BackColor = Color.Yellow;
        }


        private void Pic_Actualizar_MouseLeave(object sender, EventArgs e)
        {
            Pic_Actualizar.BackColor = Color.MintCream;
        }

        private void Pic_Salir_MouseLeave(object sender, EventArgs e)
        {
            Pic_Salir.BackColor = Color.MistyRose;
        }

        private void Pic_Minimizar_MouseLeave(object sender, EventArgs e)
        {
            Pic_Minimizar.BackColor = Color.LightYellow;
        }

       

        private void Pic_Actualizar_MouseDown(object sender, MouseEventArgs e)
        {
            Pic_Actualizar.BackColor = Color.DarkBlue;
        }

        private void Pic_Salir_MouseDown(object sender, MouseEventArgs e)
        {
            Pic_Salir.BackColor = Color.Crimson;
        }

        private void Pic_Minimizar_MouseDown(object sender, MouseEventArgs e)
        {
            Pic_Minimizar.BackColor = Color.Gold;
        }
    }
}