namespace WindowsApplication1
{
    partial class Administracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Administracion));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.productosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trabajadoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.distribuidoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tablaDistribuidoresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD_Ferreter�aDataSet = new WindowsApplication1.BD_Ferreter�aDataSet();
            this.consultaProductosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tablaDistribuidoresBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tablaRolesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.consultaTrabajadoresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tablaClientesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabla_ClientesTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.Tabla_ClientesTableAdapter();
            this.consultaProductosTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.ConsultaProductosTableAdapter();
            this.consultaTrabajadoresTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.ConsultaTrabajadoresTableAdapter();
            this.tablaDistribuidoresTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.TablaDistribuidoresTableAdapter();
            this.tablaRolesTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.TablaRolesTableAdapter();
            this.tablaClientesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.Clientes_Panel = new System.Windows.Forms.Panel();
            this.FormClientes = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.idcliente = new System.Windows.Forms.TextBox();
            this.cliente = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.Trabajadores_Panel = new System.Windows.Forms.Panel();
            this.FormTrabajadores = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.a�adirrol = new System.Windows.Forms.Panel();
            this.button24 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.rolbox = new System.Windows.Forms.ComboBox();
            this.button23 = new System.Windows.Forms.Button();
            this.rol = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.idtrabajador = new System.Windows.Forms.TextBox();
            this.trabajador = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.Productos_Panel = new System.Windows.Forms.Panel();
            this.FormProductos = new System.Windows.Forms.GroupBox();
            this.a�adirdistribuidor = new System.Windows.Forms.Panel();
            this.button21 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.Distribuidore = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.distribuidor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.idproducto = new System.Windows.Forms.TextBox();
            this.existencias = new System.Windows.Forms.TextBox();
            this.precio = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.producto = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.Distribuidores_Panel = new System.Windows.Forms.Panel();
            this.FormDistribuidores = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.button16 = new System.Windows.Forms.Button();
            this.iddistribuidor = new System.Windows.Forms.TextBox();
            this.nombredistribuidor = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.consultaTiendaTableAdapter1 = new WindowsApplication1.BD_Ferreter�aDataSet1TableAdapters.ConsultaTiendaTableAdapter();
            this.Pic_Salir = new System.Windows.Forms.PictureBox();
            this.Pic_Minimizar = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tablaDistribuidoresBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_Ferreter�aDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaProductosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaDistribuidoresBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaRolesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaTrabajadoresBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaClientesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaClientesBindingSource1)).BeginInit();
            this.Clientes_Panel.SuspendLayout();
            this.FormClientes.SuspendLayout();
            this.Trabajadores_Panel.SuspendLayout();
            this.FormTrabajadores.SuspendLayout();
            this.a�adirrol.SuspendLayout();
            this.Productos_Panel.SuspendLayout();
            this.FormProductos.SuspendLayout();
            this.a�adirdistribuidor.SuspendLayout();
            this.Distribuidores_Panel.SuspendLayout();
            this.FormDistribuidores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Salir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Minimizar)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Indigo;
            this.menuStrip1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.productosToolStripMenuItem,
            this.trabajadoresToolStripMenuItem,
            this.clientesToolStripMenuItem,
            this.distribuidoresToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(461, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // productosToolStripMenuItem
            // 
            this.productosToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.productosToolStripMenuItem.Name = "productosToolStripMenuItem";
            this.productosToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.productosToolStripMenuItem.Text = "Productos";
            this.productosToolStripMenuItem.Click += new System.EventHandler(this.productosToolStripMenuItem_Click);
            this.productosToolStripMenuItem.MouseEnter += new System.EventHandler(this.productosToolStripMenuItem_MouseEnter);
            this.productosToolStripMenuItem.MouseLeave += new System.EventHandler(this.productosToolStripMenuItem_MouseLeave);
            // 
            // trabajadoresToolStripMenuItem
            // 
            this.trabajadoresToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.trabajadoresToolStripMenuItem.Name = "trabajadoresToolStripMenuItem";
            this.trabajadoresToolStripMenuItem.Size = new System.Drawing.Size(107, 20);
            this.trabajadoresToolStripMenuItem.Text = "Trabajadores";
            this.trabajadoresToolStripMenuItem.Click += new System.EventHandler(this.trabajadoresToolStripMenuItem_Click);
            this.trabajadoresToolStripMenuItem.MouseEnter += new System.EventHandler(this.trabajadoresToolStripMenuItem_MouseEnter);
            this.trabajadoresToolStripMenuItem.MouseLeave += new System.EventHandler(this.trabajadoresToolStripMenuItem_MouseLeave);
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.clientesToolStripMenuItem.Text = "Clientes";
            this.clientesToolStripMenuItem.Click += new System.EventHandler(this.clientesToolStripMenuItem_Click);
            this.clientesToolStripMenuItem.MouseEnter += new System.EventHandler(this.clientesToolStripMenuItem_MouseEnter);
            this.clientesToolStripMenuItem.MouseLeave += new System.EventHandler(this.clientesToolStripMenuItem_MouseLeave);
            // 
            // distribuidoresToolStripMenuItem
            // 
            this.distribuidoresToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.distribuidoresToolStripMenuItem.Name = "distribuidoresToolStripMenuItem";
            this.distribuidoresToolStripMenuItem.Size = new System.Drawing.Size(112, 20);
            this.distribuidoresToolStripMenuItem.Text = "Distribuidores";
            this.distribuidoresToolStripMenuItem.Click += new System.EventHandler(this.distribuidoresToolStripMenuItem_Click);
            this.distribuidoresToolStripMenuItem.MouseEnter += new System.EventHandler(this.distribuidoresToolStripMenuItem_MouseEnter);
            this.distribuidoresToolStripMenuItem.MouseLeave += new System.EventHandler(this.distribuidoresToolStripMenuItem_MouseLeave);
            // 
            // tablaDistribuidoresBindingSource
            // 
            this.tablaDistribuidoresBindingSource.DataMember = "TablaDistribuidores";
            this.tablaDistribuidoresBindingSource.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // bD_Ferreter�aDataSet
            // 
            this.bD_Ferreter�aDataSet.DataSetName = "BD_Ferreter�aDataSet";
            this.bD_Ferreter�aDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // consultaProductosBindingSource
            // 
            this.consultaProductosBindingSource.DataMember = "ConsultaProductos";
            this.consultaProductosBindingSource.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // tablaDistribuidoresBindingSource1
            // 
            this.tablaDistribuidoresBindingSource1.DataMember = "TablaDistribuidores";
            this.tablaDistribuidoresBindingSource1.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // tablaRolesBindingSource
            // 
            this.tablaRolesBindingSource.DataMember = "TablaRoles";
            this.tablaRolesBindingSource.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // consultaTrabajadoresBindingSource
            // 
            this.consultaTrabajadoresBindingSource.DataMember = "ConsultaTrabajadores";
            this.consultaTrabajadoresBindingSource.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // tablaClientesBindingSource
            // 
            this.tablaClientesBindingSource.DataMember = "Tabla_Clientes";
            this.tablaClientesBindingSource.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // tabla_ClientesTableAdapter
            // 
            this.tabla_ClientesTableAdapter.ClearBeforeFill = true;
            // 
            // consultaProductosTableAdapter
            // 
            this.consultaProductosTableAdapter.ClearBeforeFill = true;
            // 
            // consultaTrabajadoresTableAdapter
            // 
            this.consultaTrabajadoresTableAdapter.ClearBeforeFill = true;
            // 
            // tablaDistribuidoresTableAdapter
            // 
            this.tablaDistribuidoresTableAdapter.ClearBeforeFill = true;
            // 
            // tablaRolesTableAdapter
            // 
            this.tablaRolesTableAdapter.ClearBeforeFill = true;
            // 
            // tablaClientesBindingSource1
            // 
            this.tablaClientesBindingSource1.DataMember = "Tabla_Clientes";
            this.tablaClientesBindingSource1.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // Clientes_Panel
            // 
            this.Clientes_Panel.Controls.Add(this.FormClientes);
            this.Clientes_Panel.Location = new System.Drawing.Point(13, 37);
            this.Clientes_Panel.Name = "Clientes_Panel";
            this.Clientes_Panel.Size = new System.Drawing.Size(53, 26);
            this.Clientes_Panel.TabIndex = 15;
            // 
            // FormClientes
            // 
            this.FormClientes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FormClientes.BackColor = System.Drawing.Color.AliceBlue;
            this.FormClientes.Controls.Add(this.label15);
            this.FormClientes.Controls.Add(this.comboBox3);
            this.FormClientes.Controls.Add(this.idcliente);
            this.FormClientes.Controls.Add(this.cliente);
            this.FormClientes.Controls.Add(this.label10);
            this.FormClientes.Controls.Add(this.label11);
            this.FormClientes.Controls.Add(this.button11);
            this.FormClientes.Controls.Add(this.button12);
            this.FormClientes.Controls.Add(this.button13);
            this.FormClientes.Controls.Add(this.button14);
            this.FormClientes.Controls.Add(this.button15);
            this.FormClientes.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormClientes.Location = new System.Drawing.Point(13, 16);
            this.FormClientes.Name = "FormClientes";
            this.FormClientes.Size = new System.Drawing.Size(27, 0);
            this.FormClientes.TabIndex = 20;
            this.FormClientes.TabStop = false;
            this.FormClientes.Text = "Formulario Clientes";
            this.FormClientes.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(245, 44);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 20);
            this.label15.TabIndex = 14;
            this.label15.Text = "Buscador";
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.tablaClientesBindingSource;
            this.comboBox3.DisplayMember = "ID_Cliente";
            this.comboBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(249, 65);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(159, 28);
            this.comboBox3.TabIndex = 13;
            // 
            // idcliente
            // 
            this.idcliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.idcliente.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tablaClientesBindingSource, "ID_Cliente", true));
            this.idcliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idcliente.Location = new System.Drawing.Point(94, 67);
            this.idcliente.Name = "idcliente";
            this.idcliente.Size = new System.Drawing.Size(141, 19);
            this.idcliente.TabIndex = 9;
            // 
            // cliente
            // 
            this.cliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cliente.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tablaClientesBindingSource, "Cliente", true));
            this.cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cliente.Location = new System.Drawing.Point(94, 112);
            this.cliente.Name = "cliente";
            this.cliente.Size = new System.Drawing.Size(141, 19);
            this.cliente.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(4, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 20);
            this.label10.TabIndex = 6;
            this.label10.Text = "ID Cliente:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(26, 111);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 20);
            this.label11.TabIndex = 7;
            this.label11.Text = "Cliente:";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(313, 99);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(43, 39);
            this.button11.TabIndex = 5;
            this.button11.Text = "<";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(363, 99);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(43, 39);
            this.button12.TabIndex = 5;
            this.button12.Text = ">";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(282, 154);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(126, 29);
            this.button13.TabIndex = 5;
            this.button13.Text = "Borrar";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(146, 154);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(126, 29);
            this.button14.TabIndex = 5;
            this.button14.Text = "Modificar";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(10, 154);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(126, 29);
            this.button15.TabIndex = 5;
            this.button15.Text = "Insertar";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // Trabajadores_Panel
            // 
            this.Trabajadores_Panel.Controls.Add(this.FormTrabajadores);
            this.Trabajadores_Panel.Location = new System.Drawing.Point(395, 37);
            this.Trabajadores_Panel.Name = "Trabajadores_Panel";
            this.Trabajadores_Panel.Size = new System.Drawing.Size(53, 26);
            this.Trabajadores_Panel.TabIndex = 16;
            // 
            // FormTrabajadores
            // 
            this.FormTrabajadores.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FormTrabajadores.BackColor = System.Drawing.Color.Azure;
            this.FormTrabajadores.Controls.Add(this.label16);
            this.FormTrabajadores.Controls.Add(this.a�adirrol);
            this.FormTrabajadores.Controls.Add(this.button23);
            this.FormTrabajadores.Controls.Add(this.rol);
            this.FormTrabajadores.Controls.Add(this.comboBox1);
            this.FormTrabajadores.Controls.Add(this.idtrabajador);
            this.FormTrabajadores.Controls.Add(this.trabajador);
            this.FormTrabajadores.Controls.Add(this.label3);
            this.FormTrabajadores.Controls.Add(this.label6);
            this.FormTrabajadores.Controls.Add(this.label7);
            this.FormTrabajadores.Controls.Add(this.button6);
            this.FormTrabajadores.Controls.Add(this.button7);
            this.FormTrabajadores.Controls.Add(this.button8);
            this.FormTrabajadores.Controls.Add(this.button9);
            this.FormTrabajadores.Controls.Add(this.button10);
            this.FormTrabajadores.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormTrabajadores.Location = new System.Drawing.Point(14, 16);
            this.FormTrabajadores.Name = "FormTrabajadores";
            this.FormTrabajadores.Size = new System.Drawing.Size(27, 0);
            this.FormTrabajadores.TabIndex = 4;
            this.FormTrabajadores.TabStop = false;
            this.FormTrabajadores.Text = "Formulario Trabajadores";
            this.FormTrabajadores.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(31, 100);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 17);
            this.label16.TabIndex = 25;
            this.label16.Text = "Buscador";
            // 
            // a�adirrol
            // 
            this.a�adirrol.BackColor = System.Drawing.Color.MintCream;
            this.a�adirrol.Controls.Add(this.button24);
            this.a�adirrol.Controls.Add(this.label14);
            this.a�adirrol.Controls.Add(this.rolbox);
            this.a�adirrol.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a�adirrol.Location = new System.Drawing.Point(120, 61);
            this.a�adirrol.Name = "a�adirrol";
            this.a�adirrol.Size = new System.Drawing.Size(200, 100);
            this.a�adirrol.TabIndex = 24;
            this.a�adirrol.Visible = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.SeaGreen;
            this.button24.FlatAppearance.BorderSize = 0;
            this.button24.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SpringGreen;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.ForeColor = System.Drawing.Color.White;
            this.button24.Location = new System.Drawing.Point(61, 66);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(126, 29);
            this.button24.TabIndex = 23;
            this.button24.Text = "Seleccionar";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(3, 9);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(133, 20);
            this.label14.TabIndex = 22;
            this.label14.Text = "Seleccionar rol:";
            // 
            // rolbox
            // 
            this.rolbox.DataSource = this.tablaRolesBindingSource;
            this.rolbox.DisplayMember = "Rol";
            this.rolbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rolbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rolbox.FormattingEnabled = true;
            this.rolbox.Location = new System.Drawing.Point(7, 32);
            this.rolbox.Name = "rolbox";
            this.rolbox.Size = new System.Drawing.Size(180, 28);
            this.rolbox.TabIndex = 12;
            this.rolbox.ValueMember = "ID_Rol";
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button23.FlatAppearance.BorderSize = 0;
            this.button23.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Verdana", 7.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.ForeColor = System.Drawing.Color.White;
            this.button23.Location = new System.Drawing.Point(377, 32);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(53, 19);
            this.button23.TabIndex = 14;
            this.button23.Text = "Elegir";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // rol
            // 
            this.rol.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rol.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.consultaTrabajadoresBindingSource, "Rol", true));
            this.rol.Enabled = false;
            this.rol.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rol.Location = new System.Drawing.Point(260, 32);
            this.rol.Name = "rol";
            this.rol.Size = new System.Drawing.Size(118, 19);
            this.rol.TabIndex = 13;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.consultaTrabajadoresBindingSource;
            this.comboBox1.DisplayMember = "Trabajador";
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(120, 94);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(159, 28);
            this.comboBox1.TabIndex = 12;
            // 
            // idtrabajador
            // 
            this.idtrabajador.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.idtrabajador.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.consultaTrabajadoresBindingSource, "ID_Trabajador", true));
            this.idtrabajador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idtrabajador.Location = new System.Drawing.Point(131, 32);
            this.idtrabajador.Name = "idtrabajador";
            this.idtrabajador.Size = new System.Drawing.Size(64, 19);
            this.idtrabajador.TabIndex = 9;
            // 
            // trabajador
            // 
            this.trabajador.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.trabajador.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.consultaTrabajadoresBindingSource, "Trabajador", true));
            this.trabajador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trabajador.Location = new System.Drawing.Point(131, 60);
            this.trabajador.Name = "trabajador";
            this.trabajador.Size = new System.Drawing.Size(165, 19);
            this.trabajador.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(223, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Rol:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "ID Trabajador:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(26, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Trabajador:";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(290, 94);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(34, 29);
            this.button6.TabIndex = 5;
            this.button6.Text = "<";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(330, 94);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(34, 29);
            this.button7.TabIndex = 5;
            this.button7.Text = ">";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(298, 156);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(126, 29);
            this.button8.TabIndex = 5;
            this.button8.Text = "Borrar";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button9.Enabled = false;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(156, 156);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(126, 29);
            this.button9.TabIndex = 5;
            this.button9.Text = "Modificar";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button10.Enabled = false;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(12, 156);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(126, 29);
            this.button10.TabIndex = 5;
            this.button10.Text = "Insertar";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // Productos_Panel
            // 
            this.Productos_Panel.Controls.Add(this.FormProductos);
            this.Productos_Panel.Location = new System.Drawing.Point(13, 300);
            this.Productos_Panel.Name = "Productos_Panel";
            this.Productos_Panel.Size = new System.Drawing.Size(53, 26);
            this.Productos_Panel.TabIndex = 17;
            // 
            // FormProductos
            // 
            this.FormProductos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FormProductos.BackColor = System.Drawing.Color.LightCyan;
            this.FormProductos.Controls.Add(this.a�adirdistribuidor);
            this.FormProductos.Controls.Add(this.label18);
            this.FormProductos.Controls.Add(this.button22);
            this.FormProductos.Controls.Add(this.distribuidor);
            this.FormProductos.Controls.Add(this.label2);
            this.FormProductos.Controls.Add(this.button5);
            this.FormProductos.Controls.Add(this.comboBox2);
            this.FormProductos.Controls.Add(this.idproducto);
            this.FormProductos.Controls.Add(this.existencias);
            this.FormProductos.Controls.Add(this.precio);
            this.FormProductos.Controls.Add(this.label1);
            this.FormProductos.Controls.Add(this.producto);
            this.FormProductos.Controls.Add(this.label5);
            this.FormProductos.Controls.Add(this.label8);
            this.FormProductos.Controls.Add(this.label4);
            this.FormProductos.Controls.Add(this.button1);
            this.FormProductos.Controls.Add(this.button4);
            this.FormProductos.Controls.Add(this.button2);
            this.FormProductos.Controls.Add(this.button3);
            this.FormProductos.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormProductos.Location = new System.Drawing.Point(23, 16);
            this.FormProductos.Name = "FormProductos";
            this.FormProductos.Size = new System.Drawing.Size(14, 0);
            this.FormProductos.TabIndex = 3;
            this.FormProductos.TabStop = false;
            this.FormProductos.Text = "Formulario Productos";
            this.FormProductos.Visible = false;
            // 
            // a�adirdistribuidor
            // 
            this.a�adirdistribuidor.BackColor = System.Drawing.Color.MediumTurquoise;
            this.a�adirdistribuidor.Controls.Add(this.button21);
            this.a�adirdistribuidor.Controls.Add(this.label9);
            this.a�adirdistribuidor.Controls.Add(this.Distribuidore);
            this.a�adirdistribuidor.Location = new System.Drawing.Point(110, 88);
            this.a�adirdistribuidor.Name = "a�adirdistribuidor";
            this.a�adirdistribuidor.Size = new System.Drawing.Size(215, 100);
            this.a�adirdistribuidor.TabIndex = 23;
            this.a�adirdistribuidor.Visible = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.RoyalBlue;
            this.button21.FlatAppearance.BorderSize = 0;
            this.button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.ForeColor = System.Drawing.Color.White;
            this.button21.Location = new System.Drawing.Point(79, 66);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(126, 29);
            this.button21.TabIndex = 23;
            this.button21.Text = "Seleccionar";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(202, 20);
            this.label9.TabIndex = 22;
            this.label9.Text = "Seleccionar distribuidor:";
            // 
            // Distribuidore
            // 
            this.Distribuidore.DataSource = this.tablaDistribuidoresBindingSource;
            this.Distribuidore.DisplayMember = "Distribuidor";
            this.Distribuidore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Distribuidore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Distribuidore.FormattingEnabled = true;
            this.Distribuidore.Location = new System.Drawing.Point(7, 33);
            this.Distribuidore.Name = "Distribuidore";
            this.Distribuidore.Size = new System.Drawing.Size(198, 28);
            this.Distribuidore.TabIndex = 12;
            this.Distribuidore.ValueMember = "ID_Distribuidor";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(234, 98);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(76, 17);
            this.label18.TabIndex = 26;
            this.label18.Text = "Buscador";
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.DarkCyan;
            this.button22.FlatAppearance.BorderSize = 0;
            this.button22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleTurquoise;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Location = new System.Drawing.Point(342, 17);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(56, 23);
            this.button22.TabIndex = 25;
            this.button22.Text = "Elegir";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click_1);
            // 
            // distribuidor
            // 
            this.distribuidor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.distribuidor.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.consultaProductosBindingSource, "Distribuidor", true));
            this.distribuidor.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.consultaProductosBindingSource, "ID Distribuidor", true));
            this.distribuidor.Enabled = false;
            this.distribuidor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.distribuidor.Location = new System.Drawing.Point(237, 45);
            this.distribuidor.Name = "distribuidor";
            this.distribuidor.Size = new System.Drawing.Size(161, 19);
            this.distribuidor.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(234, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 17);
            this.label2.TabIndex = 22;
            this.label2.Text = "Distribuidor:";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkCyan;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleTurquoise;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(322, 83);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(35, 29);
            this.button5.TabIndex = 13;
            this.button5.Text = "<";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.consultaProductosBindingSource;
            this.comboBox2.DisplayMember = "Producto";
            this.comboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(237, 118);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(161, 28);
            this.comboBox2.TabIndex = 12;
            // 
            // idproducto
            // 
            this.idproducto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.idproducto.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.consultaProductosBindingSource, "ID_Producto", true));
            this.idproducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idproducto.Location = new System.Drawing.Point(110, 34);
            this.idproducto.Name = "idproducto";
            this.idproducto.Size = new System.Drawing.Size(105, 19);
            this.idproducto.TabIndex = 9;
            // 
            // existencias
            // 
            this.existencias.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.existencias.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.consultaProductosBindingSource, "Existencias", true));
            this.existencias.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.existencias.Location = new System.Drawing.Point(110, 125);
            this.existencias.Name = "existencias";
            this.existencias.Size = new System.Drawing.Size(105, 19);
            this.existencias.TabIndex = 10;
            // 
            // precio
            // 
            this.precio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.precio.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.consultaProductosBindingSource, "Precio", true));
            this.precio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.precio.Location = new System.Drawing.Point(110, 94);
            this.precio.Name = "precio";
            this.precio.Size = new System.Drawing.Size(105, 19);
            this.precio.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Existencias:";
            // 
            // producto
            // 
            this.producto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.producto.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.consultaProductosBindingSource, "Producto", true));
            this.producto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.producto.Location = new System.Drawing.Point(110, 63);
            this.producto.Name = "producto";
            this.producto.Size = new System.Drawing.Size(105, 19);
            this.producto.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(48, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Precio:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(9, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 17);
            this.label8.TabIndex = 6;
            this.label8.Text = "ID Producto:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Producto:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkCyan;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleTurquoise;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(363, 83);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 29);
            this.button1.TabIndex = 5;
            this.button1.Text = ">";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkCyan;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleTurquoise;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(276, 182);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(126, 29);
            this.button4.TabIndex = 5;
            this.button4.Text = "Borrar";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkCyan;
            this.button2.Enabled = false;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleTurquoise;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(144, 182);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(126, 29);
            this.button2.TabIndex = 5;
            this.button2.Text = "Modificar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkCyan;
            this.button3.Enabled = false;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleTurquoise;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(12, 182);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(126, 29);
            this.button3.TabIndex = 5;
            this.button3.Text = "Insertar";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Distribuidores_Panel
            // 
            this.Distribuidores_Panel.Controls.Add(this.FormDistribuidores);
            this.Distribuidores_Panel.Location = new System.Drawing.Point(395, 301);
            this.Distribuidores_Panel.Name = "Distribuidores_Panel";
            this.Distribuidores_Panel.Size = new System.Drawing.Size(53, 26);
            this.Distribuidores_Panel.TabIndex = 18;
            // 
            // FormDistribuidores
            // 
            this.FormDistribuidores.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FormDistribuidores.BackColor = System.Drawing.Color.GhostWhite;
            this.FormDistribuidores.Controls.Add(this.label17);
            this.FormDistribuidores.Controls.Add(this.comboBox4);
            this.FormDistribuidores.Controls.Add(this.button16);
            this.FormDistribuidores.Controls.Add(this.iddistribuidor);
            this.FormDistribuidores.Controls.Add(this.nombredistribuidor);
            this.FormDistribuidores.Controls.Add(this.label12);
            this.FormDistribuidores.Controls.Add(this.label13);
            this.FormDistribuidores.Controls.Add(this.button17);
            this.FormDistribuidores.Controls.Add(this.button18);
            this.FormDistribuidores.Controls.Add(this.button19);
            this.FormDistribuidores.Controls.Add(this.button20);
            this.FormDistribuidores.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormDistribuidores.Location = new System.Drawing.Point(26, 16);
            this.FormDistribuidores.Name = "FormDistribuidores";
            this.FormDistribuidores.Size = new System.Drawing.Size(0, 0);
            this.FormDistribuidores.TabIndex = 5;
            this.FormDistribuidores.TabStop = false;
            this.FormDistribuidores.Text = "Formulario distribuidores";
            this.FormDistribuidores.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(47, 118);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(76, 17);
            this.label17.TabIndex = 24;
            this.label17.Text = "Buscador";
            // 
            // comboBox4
            // 
            this.comboBox4.DataSource = this.tablaDistribuidoresBindingSource;
            this.comboBox4.DisplayMember = "Distribuidor";
            this.comboBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(129, 112);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(145, 28);
            this.comboBox4.TabIndex = 23;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.DarkViolet;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumPurple;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(292, 113);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(31, 29);
            this.button16.TabIndex = 22;
            this.button16.Text = "<";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // iddistribuidor
            // 
            this.iddistribuidor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.iddistribuidor.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tablaDistribuidoresBindingSource, "ID_Distribuidor", true));
            this.iddistribuidor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iddistribuidor.Location = new System.Drawing.Point(133, 30);
            this.iddistribuidor.Name = "iddistribuidor";
            this.iddistribuidor.Size = new System.Drawing.Size(64, 19);
            this.iddistribuidor.TabIndex = 20;
            // 
            // nombredistribuidor
            // 
            this.nombredistribuidor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nombredistribuidor.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tablaDistribuidoresBindingSource, "Distribuidor", true));
            this.nombredistribuidor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombredistribuidor.Location = new System.Drawing.Point(133, 73);
            this.nombredistribuidor.Name = "nombredistribuidor";
            this.nombredistribuidor.Size = new System.Drawing.Size(165, 19);
            this.nombredistribuidor.TabIndex = 21;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(117, 17);
            this.label12.TabIndex = 18;
            this.label12.Text = "ID Distribuidor:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(30, 71);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 17);
            this.label13.TabIndex = 19;
            this.label13.Text = "Distribuidor:";
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.DarkViolet;
            this.button17.FlatAppearance.BorderSize = 0;
            this.button17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumPurple;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.White;
            this.button17.Location = new System.Drawing.Point(326, 113);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(31, 29);
            this.button17.TabIndex = 15;
            this.button17.Text = ">";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.DarkViolet;
            this.button18.FlatAppearance.BorderSize = 0;
            this.button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumPurple;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(268, 173);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(89, 29);
            this.button18.TabIndex = 14;
            this.button18.Text = "Borrar";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.DarkViolet;
            this.button19.FlatAppearance.BorderSize = 0;
            this.button19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumPurple;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.Color.White;
            this.button19.Location = new System.Drawing.Point(154, 173);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(94, 29);
            this.button19.TabIndex = 17;
            this.button19.Text = "Modificar";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.DarkViolet;
            this.button20.FlatAppearance.BorderSize = 0;
            this.button20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumPurple;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.ForeColor = System.Drawing.Color.White;
            this.button20.Location = new System.Drawing.Point(42, 173);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(94, 29);
            this.button20.TabIndex = 16;
            this.button20.Text = "Insertar";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // consultaTiendaTableAdapter1
            // 
            this.consultaTiendaTableAdapter1.ClearBeforeFill = true;
            // 
            // Pic_Salir
            // 
            this.Pic_Salir.BackColor = System.Drawing.Color.MistyRose;
            this.Pic_Salir.Image = ((System.Drawing.Image)(resources.GetObject("Pic_Salir.Image")));
            this.Pic_Salir.Location = new System.Drawing.Point(438, 0);
            this.Pic_Salir.Name = "Pic_Salir";
            this.Pic_Salir.Size = new System.Drawing.Size(24, 24);
            this.Pic_Salir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_Salir.TabIndex = 19;
            this.Pic_Salir.TabStop = false;
            this.Pic_Salir.Click += new System.EventHandler(this.Pic_Salir_Click);
            this.Pic_Salir.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pic_Salir_MouseDown);
            this.Pic_Salir.MouseEnter += new System.EventHandler(this.Pic_Salir_MouseEnter);
            this.Pic_Salir.MouseLeave += new System.EventHandler(this.Pic_Salir_MouseLeave);
            // 
            // Pic_Minimizar
            // 
            this.Pic_Minimizar.BackColor = System.Drawing.Color.LightYellow;
            this.Pic_Minimizar.Image = ((System.Drawing.Image)(resources.GetObject("Pic_Minimizar.Image")));
            this.Pic_Minimizar.Location = new System.Drawing.Point(414, 0);
            this.Pic_Minimizar.Name = "Pic_Minimizar";
            this.Pic_Minimizar.Size = new System.Drawing.Size(24, 24);
            this.Pic_Minimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_Minimizar.TabIndex = 19;
            this.Pic_Minimizar.TabStop = false;
            this.Pic_Minimizar.Click += new System.EventHandler(this.Pic_Minimizar_Click);
            this.Pic_Minimizar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pic_Minimizar_MouseDown);
            this.Pic_Minimizar.MouseEnter += new System.EventHandler(this.Pic_Minimizar_MouseEnter);
            this.Pic_Minimizar.MouseLeave += new System.EventHandler(this.Pic_Minimizar_MouseLeave);
            // 
            // Administracion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(461, 338);
            this.Controls.Add(this.Pic_Minimizar);
            this.Controls.Add(this.Pic_Salir);
            this.Controls.Add(this.Distribuidores_Panel);
            this.Controls.Add(this.Productos_Panel);
            this.Controls.Add(this.Trabajadores_Panel);
            this.Controls.Add(this.Clientes_Panel);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Administracion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Administracion";
            this.Load += new System.EventHandler(this.Administracion_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tablaDistribuidoresBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_Ferreter�aDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaProductosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaDistribuidoresBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaRolesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaTrabajadoresBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaClientesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaClientesBindingSource1)).EndInit();
            this.Clientes_Panel.ResumeLayout(false);
            this.FormClientes.ResumeLayout(false);
            this.FormClientes.PerformLayout();
            this.Trabajadores_Panel.ResumeLayout(false);
            this.FormTrabajadores.ResumeLayout(false);
            this.FormTrabajadores.PerformLayout();
            this.a�adirrol.ResumeLayout(false);
            this.a�adirrol.PerformLayout();
            this.Productos_Panel.ResumeLayout(false);
            this.FormProductos.ResumeLayout(false);
            this.FormProductos.PerformLayout();
            this.a�adirdistribuidor.ResumeLayout(false);
            this.a�adirdistribuidor.PerformLayout();
            this.Distribuidores_Panel.ResumeLayout(false);
            this.FormDistribuidores.ResumeLayout(false);
            this.FormDistribuidores.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Salir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Minimizar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem productosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trabajadoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private BD_Ferreter�aDataSet bD_Ferreter�aDataSet;
        private System.Windows.Forms.BindingSource tablaClientesBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.Tabla_ClientesTableAdapter tabla_ClientesTableAdapter;
        private System.Windows.Forms.BindingSource consultaProductosBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.ConsultaProductosTableAdapter consultaProductosTableAdapter;
        private System.Windows.Forms.BindingSource consultaTrabajadoresBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.ConsultaTrabajadoresTableAdapter consultaTrabajadoresTableAdapter;
        private System.Windows.Forms.ToolStripMenuItem distribuidoresToolStripMenuItem;
        private System.Windows.Forms.BindingSource tablaDistribuidoresBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.TablaDistribuidoresTableAdapter tablaDistribuidoresTableAdapter;
        private System.Windows.Forms.BindingSource tablaDistribuidoresBindingSource1;
        private System.Windows.Forms.BindingSource tablaRolesBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.TablaRolesTableAdapter tablaRolesTableAdapter;
        private System.Windows.Forms.BindingSource tablaClientesBindingSource1;
        private System.Windows.Forms.Panel Clientes_Panel;
        private System.Windows.Forms.Panel Trabajadores_Panel;
        private System.Windows.Forms.GroupBox FormTrabajadores;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel a�adirrol;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox rolbox;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.TextBox rol;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox idtrabajador;
        private System.Windows.Forms.TextBox trabajador;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel Productos_Panel;
        private System.Windows.Forms.Panel Distribuidores_Panel;
        private System.Windows.Forms.GroupBox FormDistribuidores;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TextBox iddistribuidor;
        private System.Windows.Forms.TextBox nombredistribuidor;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.GroupBox FormProductos;
        private System.Windows.Forms.Panel a�adirdistribuidor;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox Distribuidore;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.TextBox distribuidor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox idproducto;
        private System.Windows.Forms.TextBox existencias;
        private System.Windows.Forms.TextBox precio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox producto;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox FormClientes;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox idcliente;
        private System.Windows.Forms.TextBox cliente;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private BD_Ferreter�aDataSet1TableAdapters.ConsultaTiendaTableAdapter consultaTiendaTableAdapter1;
        private System.Windows.Forms.PictureBox Pic_Salir;
        private System.Windows.Forms.PictureBox Pic_Minimizar;
    }
}