using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BTN_Tienda_Click(object sender, EventArgs e)
        {
            Tienda Tienda = new Tienda();
            Tienda.ShowDialog();
        }

        private void BTN_Admin_Click(object sender, EventArgs e)
        {
            Administracion Administracion = new Administracion();
            Administracion.ShowDialog();
        }

        private void BTN_Consulta_Click(object sender, EventArgs e)
        {
            Consultas Consultas = new Consultas();
            Consultas.ShowDialog();
        }

        
    }
}