namespace WindowsApplication1
{
    partial class Consultas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Consultas));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.productosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trabajadoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.distribuidoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabla = new System.Windows.Forms.DataGridView();
            this.busqueda = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Pic_Actualizar = new System.Windows.Forms.PictureBox();
            this.Pic_Salir = new System.Windows.Forms.PictureBox();
            this.Pic_Minimizar = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabla)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Actualizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Salir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Minimizar)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.PeachPuff;
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.productosToolStripMenuItem,
            this.trabajadoresToolStripMenuItem,
            this.clientesToolStripMenuItem,
            this.distribuidoresToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(520, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // productosToolStripMenuItem
            // 
            this.productosToolStripMenuItem.Name = "productosToolStripMenuItem";
            this.productosToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.productosToolStripMenuItem.Text = "Productos";
            this.productosToolStripMenuItem.Click += new System.EventHandler(this.productosToolStripMenuItem_Click);
            this.productosToolStripMenuItem.MouseEnter += new System.EventHandler(this.productosToolStripMenuItem_MouseEnter);
            this.productosToolStripMenuItem.MouseLeave += new System.EventHandler(this.productosToolStripMenuItem_MouseLeave);
            // 
            // trabajadoresToolStripMenuItem
            // 
            this.trabajadoresToolStripMenuItem.Name = "trabajadoresToolStripMenuItem";
            this.trabajadoresToolStripMenuItem.Size = new System.Drawing.Size(109, 20);
            this.trabajadoresToolStripMenuItem.Text = "Trabajadores";
            this.trabajadoresToolStripMenuItem.Click += new System.EventHandler(this.trabajadoresToolStripMenuItem_Click);
            this.trabajadoresToolStripMenuItem.MouseEnter += new System.EventHandler(this.trabajadoresToolStripMenuItem_MouseEnter);
            this.trabajadoresToolStripMenuItem.MouseLeave += new System.EventHandler(this.trabajadoresToolStripMenuItem_MouseLeave);
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.clientesToolStripMenuItem.Text = "Clientes";
            this.clientesToolStripMenuItem.Click += new System.EventHandler(this.clientesToolStripMenuItem_Click);
            this.clientesToolStripMenuItem.MouseEnter += new System.EventHandler(this.clientesToolStripMenuItem_MouseEnter);
            this.clientesToolStripMenuItem.MouseLeave += new System.EventHandler(this.clientesToolStripMenuItem_MouseLeave);
            // 
            // distribuidoresToolStripMenuItem
            // 
            this.distribuidoresToolStripMenuItem.Name = "distribuidoresToolStripMenuItem";
            this.distribuidoresToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.distribuidoresToolStripMenuItem.Text = "Facturas";
            this.distribuidoresToolStripMenuItem.Click += new System.EventHandler(this.distribuidoresToolStripMenuItem_Click);
            this.distribuidoresToolStripMenuItem.MouseEnter += new System.EventHandler(this.distribuidoresToolStripMenuItem_MouseEnter);
            this.distribuidoresToolStripMenuItem.MouseLeave += new System.EventHandler(this.distribuidoresToolStripMenuItem_MouseLeave);
            // 
            // tabla
            // 
            this.tabla.AllowUserToAddRows = false;
            this.tabla.AllowUserToDeleteRows = false;
            this.tabla.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.tabla.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tabla.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.tabla.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.tabla.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.tabla.ColumnHeadersHeight = 22;
            this.tabla.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.tabla.EnableHeadersVisualStyles = false;
            this.tabla.GridColor = System.Drawing.Color.Black;
            this.tabla.Location = new System.Drawing.Point(24, 78);
            this.tabla.MultiSelect = false;
            this.tabla.Name = "tabla";
            this.tabla.ReadOnly = true;
            this.tabla.RowHeadersVisible = false;
            this.tabla.RowTemplate.ReadOnly = true;
            this.tabla.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.tabla.Size = new System.Drawing.Size(469, 176);
            this.tabla.TabIndex = 2;
            // 
            // busqueda
            // 
            this.busqueda.BackColor = System.Drawing.Color.NavajoWhite;
            this.busqueda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.busqueda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.busqueda.Location = new System.Drawing.Point(105, 48);
            this.busqueda.Multiline = true;
            this.busqueda.Name = "busqueda";
            this.busqueda.Size = new System.Drawing.Size(146, 24);
            this.busqueda.TabIndex = 10;
            this.busqueda.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.busqueda_KeyPress);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkSalmon;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Maiandra GD", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(24, 46);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 26);
            this.button1.TabIndex = 11;
            this.button1.Text = "Buscar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Pic_Actualizar
            // 
            this.Pic_Actualizar.BackColor = System.Drawing.Color.MintCream;
            this.Pic_Actualizar.Image = ((System.Drawing.Image)(resources.GetObject("Pic_Actualizar.Image")));
            this.Pic_Actualizar.Location = new System.Drawing.Point(466, 48);
            this.Pic_Actualizar.Name = "Pic_Actualizar";
            this.Pic_Actualizar.Size = new System.Drawing.Size(27, 24);
            this.Pic_Actualizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_Actualizar.TabIndex = 12;
            this.Pic_Actualizar.TabStop = false;
            this.Pic_Actualizar.Click += new System.EventHandler(this.Pic_Actualizar_Click);
            this.Pic_Actualizar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pic_Actualizar_MouseDown);
            this.Pic_Actualizar.MouseEnter += new System.EventHandler(this.Pic_Actualizar_MouseEnter);
            this.Pic_Actualizar.MouseLeave += new System.EventHandler(this.Pic_Actualizar_MouseLeave);
            // 
            // Pic_Salir
            // 
            this.Pic_Salir.BackColor = System.Drawing.Color.MistyRose;
            this.Pic_Salir.Image = ((System.Drawing.Image)(resources.GetObject("Pic_Salir.Image")));
            this.Pic_Salir.Location = new System.Drawing.Point(493, 0);
            this.Pic_Salir.Name = "Pic_Salir";
            this.Pic_Salir.Size = new System.Drawing.Size(27, 24);
            this.Pic_Salir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_Salir.TabIndex = 12;
            this.Pic_Salir.TabStop = false;
            this.Pic_Salir.Click += new System.EventHandler(this.Pic_Salir_Click);
            this.Pic_Salir.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pic_Salir_MouseDown);
            this.Pic_Salir.MouseEnter += new System.EventHandler(this.Pic_Salir_MouseEnter);
            this.Pic_Salir.MouseLeave += new System.EventHandler(this.Pic_Salir_MouseLeave);
            // 
            // Pic_Minimizar
            // 
            this.Pic_Minimizar.BackColor = System.Drawing.Color.LightYellow;
            this.Pic_Minimizar.Image = ((System.Drawing.Image)(resources.GetObject("Pic_Minimizar.Image")));
            this.Pic_Minimizar.Location = new System.Drawing.Point(467, 0);
            this.Pic_Minimizar.Name = "Pic_Minimizar";
            this.Pic_Minimizar.Size = new System.Drawing.Size(27, 24);
            this.Pic_Minimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_Minimizar.TabIndex = 12;
            this.Pic_Minimizar.TabStop = false;
            this.Pic_Minimizar.Click += new System.EventHandler(this.Pic_Minimizar_Click);
            this.Pic_Minimizar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pic_Minimizar_MouseDown);
            this.Pic_Minimizar.MouseEnter += new System.EventHandler(this.Pic_Minimizar_MouseEnter);
            this.Pic_Minimizar.MouseLeave += new System.EventHandler(this.Pic_Minimizar_MouseLeave);
            // 
            // Consultas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(520, 279);
            this.Controls.Add(this.Pic_Salir);
            this.Controls.Add(this.Pic_Minimizar);
            this.Controls.Add(this.Pic_Actualizar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.busqueda);
            this.Controls.Add(this.tabla);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Consultas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Consultas";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabla)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Actualizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Salir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Minimizar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem productosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trabajadoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem distribuidoresToolStripMenuItem;
        private System.Windows.Forms.DataGridView tabla;
        private System.Windows.Forms.TextBox busqueda;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox Pic_Actualizar;
        private System.Windows.Forms.PictureBox Pic_Salir;
        private System.Windows.Forms.PictureBox Pic_Minimizar;
    }
}