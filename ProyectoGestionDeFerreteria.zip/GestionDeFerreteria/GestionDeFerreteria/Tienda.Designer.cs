namespace WindowsApplication1
{
    partial class Tienda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tienda));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.FormCliente = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.cliente = new System.Windows.Forms.TextBox();
            this.idcliente = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDClienteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clienteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tablaClientesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD_Ferreter�aDataSet = new WindowsApplication1.BD_Ferreter�aDataSet();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.busqueda = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BTN_ComenzarVenta = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Existencias = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.producto = new System.Windows.Forms.TextBox();
            this.existencia = new System.Windows.Forms.TextBox();
            this.precio = new System.Windows.Forms.TextBox();
            this.idproducto = new System.Windows.Forms.TextBox();
            this.total = new System.Windows.Forms.TextBox();
            this.FormTienda = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button16 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.iDProductoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.precioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.existenciasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.consultaTiendaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD_Ferreter�aDataSet1 = new WindowsApplication1.BD_Ferreter�aDataSet1();
            this.button12 = new System.Windows.Forms.Button();
            this.busqueda2 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.button15 = new System.Windows.Forms.Button();
            this.cantidad = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.nombrecliente = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.clienteid = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabla_ClientesTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.Tabla_ClientesTableAdapter();
            this.tablaProductosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tablaProductosTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.TablaProductosTableAdapter();
            this.consultaTiendaTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSet1TableAdapters.ConsultaTiendaTableAdapter();
            this.Pic_Salir = new System.Windows.Forms.PictureBox();
            this.Pic_Minimizar = new System.Windows.Forms.PictureBox();
            this.FormCliente.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaClientesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_Ferreter�aDataSet)).BeginInit();
            this.FormTienda.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaTiendaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_Ferreter�aDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaProductosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Salir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Minimizar)).BeginInit();
            this.SuspendLayout();
            // 
            // FormCliente
            // 
            this.FormCliente.BackColor = System.Drawing.Color.Honeydew;
            this.FormCliente.Controls.Add(this.panel1);
            this.FormCliente.Controls.Add(this.button10);
            this.FormCliente.Controls.Add(this.button9);
            this.FormCliente.Controls.Add(this.dataGridView1);
            this.FormCliente.Controls.Add(this.label7);
            this.FormCliente.Controls.Add(this.textBox2);
            this.FormCliente.Controls.Add(this.busqueda);
            this.FormCliente.Controls.Add(this.label23);
            this.FormCliente.Controls.Add(this.textBox1);
            this.FormCliente.Controls.Add(this.label2);
            this.FormCliente.Controls.Add(this.label19);
            this.FormCliente.Controls.Add(this.label9);
            this.FormCliente.Controls.Add(this.label1);
            this.FormCliente.Controls.Add(this.BTN_ComenzarVenta);
            this.FormCliente.Controls.Add(this.button11);
            this.FormCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FormCliente.Font = new System.Drawing.Font("Segoe UI Emoji", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormCliente.Location = new System.Drawing.Point(12, 18);
            this.FormCliente.Name = "FormCliente";
            this.FormCliente.Size = new System.Drawing.Size(360, 357);
            this.FormCliente.TabIndex = 0;
            this.FormCliente.TabStop = false;
            this.FormCliente.Text = "Seleccionar Cliente";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PaleGreen;
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.cliente);
            this.panel1.Controls.Add(this.idcliente);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Location = new System.Drawing.Point(47, 56);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(277, 188);
            this.panel1.TabIndex = 5;
            this.panel1.Visible = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Aquamarine;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(256, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(21, 20);
            this.button8.TabIndex = 9;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // cliente
            // 
            this.cliente.BackColor = System.Drawing.Color.Honeydew;
            this.cliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cliente.Location = new System.Drawing.Point(84, 100);
            this.cliente.Name = "cliente";
            this.cliente.Size = new System.Drawing.Size(157, 19);
            this.cliente.TabIndex = 7;
            // 
            // idcliente
            // 
            this.idcliente.BackColor = System.Drawing.Color.Honeydew;
            this.idcliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.idcliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idcliente.Location = new System.Drawing.Point(84, 71);
            this.idcliente.Name = "idcliente";
            this.idcliente.Size = new System.Drawing.Size(157, 19);
            this.idcliente.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 98);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 21);
            this.label10.TabIndex = 6;
            this.label10.Text = "Nombre:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(231, 137);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 15);
            this.label18.TabIndex = 5;
            this.label18.Text = "A�adir";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(73, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(134, 21);
            this.label12.TabIndex = 5;
            this.label12.Text = "Agregar clientes";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(49, 69);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 21);
            this.label11.TabIndex = 5;
            this.label11.Text = "ID:";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Aquamarine;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(236, 154);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(32, 31);
            this.button7.TabIndex = 4;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.ForestGreen;
            this.button10.FlatAppearance.BorderColor = System.Drawing.Color.LightGreen;
            this.button10.FlatAppearance.BorderSize = 3;
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LimeGreen;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Segoe UI Black", 9F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(18, 30);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(144, 26);
            this.button10.TabIndex = 10;
            this.button10.Text = "Buscar ID Cliente:";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Aquamarine;
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightBlue;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Segoe UI Black", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(18, 63);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(27, 26);
            this.button9.TabIndex = 6;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Honeydew;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.LawnGreen;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeight = 30;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDClienteDataGridViewTextBoxColumn,
            this.clienteDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tablaClientesBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(18, 95);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.ReadOnly = true;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.Size = new System.Drawing.Size(328, 173);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.TabStop = false;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // iDClienteDataGridViewTextBoxColumn
            // 
            this.iDClienteDataGridViewTextBoxColumn.DataPropertyName = "ID_Cliente";
            this.iDClienteDataGridViewTextBoxColumn.HeaderText = "ID_Cliente";
            this.iDClienteDataGridViewTextBoxColumn.Name = "iDClienteDataGridViewTextBoxColumn";
            this.iDClienteDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // clienteDataGridViewTextBoxColumn
            // 
            this.clienteDataGridViewTextBoxColumn.DataPropertyName = "Cliente";
            this.clienteDataGridViewTextBoxColumn.HeaderText = "Cliente";
            this.clienteDataGridViewTextBoxColumn.Name = "clienteDataGridViewTextBoxColumn";
            this.clienteDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tablaClientesBindingSource
            // 
            this.tablaClientesBindingSource.DataMember = "Tabla_Clientes";
            this.tablaClientesBindingSource.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // bD_Ferreter�aDataSet
            // 
            this.bD_Ferreter�aDataSet.DataSetName = "BD_Ferreter�aDataSet";
            this.bD_Ferreter�aDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Honeydew;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkGreen;
            this.label7.Location = new System.Drawing.Point(59, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Cliente Seleccionado";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.PowderBlue;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tablaClientesBindingSource, "Cliente", true));
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tablaClientesBindingSource, "ID_Cliente", true));
            this.textBox2.Enabled = false;
            this.textBox2.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.DimGray;
            this.textBox2.Location = new System.Drawing.Point(118, 311);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(125, 17);
            this.textBox2.TabIndex = 3;
            // 
            // busqueda
            // 
            this.busqueda.BackColor = System.Drawing.Color.LightGreen;
            this.busqueda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.busqueda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.busqueda.Location = new System.Drawing.Point(162, 30);
            this.busqueda.Multiline = true;
            this.busqueda.Name = "busqueda";
            this.busqueda.Size = new System.Drawing.Size(133, 26);
            this.busqueda.TabIndex = 3;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label23.Font = new System.Drawing.Font("Segoe UI Black", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label23.Location = new System.Drawing.Point(293, 322);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 15);
            this.label23.TabIndex = 17;
            this.label23.Text = " Vender";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.PowderBlue;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tablaClientesBindingSource, "ID_Cliente", true));
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tablaClientesBindingSource, "ID_Cliente", true));
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.DimGray;
            this.textBox1.Location = new System.Drawing.Point(118, 294);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(125, 17);
            this.textBox1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.PowderBlue;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(58, 309);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Cliente: ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Honeydew;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.DarkGreen;
            this.label19.Location = new System.Drawing.Point(229, 69);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 15);
            this.label19.TabIndex = 2;
            this.label19.Text = "Actualizar";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Honeydew;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkGreen;
            this.label9.Location = new System.Drawing.Point(44, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 15);
            this.label9.TabIndex = 2;
            this.label9.Text = "Agregar nuevo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PowderBlue;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(58, 294);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "       ID:  ";
            // 
            // BTN_ComenzarVenta
            // 
            this.BTN_ComenzarVenta.BackColor = System.Drawing.Color.ForestGreen;
            this.BTN_ComenzarVenta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BTN_ComenzarVenta.BackgroundImage")));
            this.BTN_ComenzarVenta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BTN_ComenzarVenta.FlatAppearance.BorderColor = System.Drawing.Color.LightGreen;
            this.BTN_ComenzarVenta.FlatAppearance.BorderSize = 3;
            this.BTN_ComenzarVenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.BTN_ComenzarVenta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LimeGreen;
            this.BTN_ComenzarVenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_ComenzarVenta.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_ComenzarVenta.ForeColor = System.Drawing.Color.White;
            this.BTN_ComenzarVenta.Location = new System.Drawing.Point(296, 274);
            this.BTN_ComenzarVenta.Name = "BTN_ComenzarVenta";
            this.BTN_ComenzarVenta.Size = new System.Drawing.Size(50, 45);
            this.BTN_ComenzarVenta.TabIndex = 0;
            this.BTN_ComenzarVenta.Text = "\r\n";
            this.BTN_ComenzarVenta.UseVisualStyleBackColor = false;
            this.BTN_ComenzarVenta.Click += new System.EventHandler(this.BTN_ComenzarVenta_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Aquamarine;
            this.button11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button11.BackgroundImage")));
            this.button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightBlue;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(203, 63);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(27, 26);
            this.button11.TabIndex = 11;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(372, 307);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(31, 30);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(303, 112);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(37, 33);
            this.button3.TabIndex = 0;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(339, 307);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(31, 30);
            this.button5.TabIndex = 0;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Teal;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Turquoise;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(16, 274);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 45);
            this.button2.TabIndex = 0;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(-334, 196);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 29);
            this.button4.TabIndex = 0;
            this.button4.Text = "Volver\r\n";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(-334, 247);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(87, 29);
            this.button6.TabIndex = 0;
            this.button6.Text = "Volver\r\n";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Azure;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(100, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 21);
            this.label4.TabIndex = 2;
            this.label4.Text = "Producto: ";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Azure;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(100, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Precio: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Azure;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(100, 88);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 21);
            this.label8.TabIndex = 2;
            this.label8.Text = "ID Producto: ";
            // 
            // Existencias
            // 
            this.Existencias.AutoSize = true;
            this.Existencias.BackColor = System.Drawing.Color.Azure;
            this.Existencias.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Existencias.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Existencias.ForeColor = System.Drawing.Color.DimGray;
            this.Existencias.Location = new System.Drawing.Point(100, 130);
            this.Existencias.Name = "Existencias";
            this.Existencias.Size = new System.Drawing.Size(97, 21);
            this.Existencias.TabIndex = 2;
            this.Existencias.Text = "Existencias: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Aquamarine;
            this.label6.Font = new System.Drawing.Font("Segoe UI Black", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(207, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 30);
            this.label6.TabIndex = 2;
            this.label6.Text = " Total: ";
            // 
            // producto
            // 
            this.producto.BackColor = System.Drawing.Color.Azure;
            this.producto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.producto.Enabled = false;
            this.producto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.producto.ForeColor = System.Drawing.Color.DimGray;
            this.producto.Location = new System.Drawing.Point(183, 67);
            this.producto.Multiline = true;
            this.producto.Name = "producto";
            this.producto.Size = new System.Drawing.Size(100, 22);
            this.producto.TabIndex = 3;
            this.producto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // existencia
            // 
            this.existencia.BackColor = System.Drawing.Color.Azure;
            this.existencia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.existencia.Enabled = false;
            this.existencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.existencia.ForeColor = System.Drawing.Color.DimGray;
            this.existencia.Location = new System.Drawing.Point(197, 131);
            this.existencia.Multiline = true;
            this.existencia.Name = "existencia";
            this.existencia.Size = new System.Drawing.Size(86, 20);
            this.existencia.TabIndex = 3;
            this.existencia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // precio
            // 
            this.precio.BackColor = System.Drawing.Color.Azure;
            this.precio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.precio.Enabled = false;
            this.precio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.precio.ForeColor = System.Drawing.Color.DimGray;
            this.precio.Location = new System.Drawing.Point(163, 109);
            this.precio.Multiline = true;
            this.precio.Name = "precio";
            this.precio.Size = new System.Drawing.Size(120, 22);
            this.precio.TabIndex = 3;
            this.precio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.precio.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // idproducto
            // 
            this.idproducto.BackColor = System.Drawing.Color.Azure;
            this.idproducto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.idproducto.Enabled = false;
            this.idproducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idproducto.ForeColor = System.Drawing.Color.DimGray;
            this.idproducto.Location = new System.Drawing.Point(204, 89);
            this.idproducto.Multiline = true;
            this.idproducto.Name = "idproducto";
            this.idproducto.Size = new System.Drawing.Size(79, 20);
            this.idproducto.TabIndex = 3;
            this.idproducto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.idproducto.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // total
            // 
            this.total.BackColor = System.Drawing.Color.Aquamarine;
            this.total.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.total.Enabled = false;
            this.total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total.Location = new System.Drawing.Point(295, 274);
            this.total.Multiline = true;
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(108, 30);
            this.total.TabIndex = 3;
            this.total.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // FormTienda
            // 
            this.FormTienda.BackColor = System.Drawing.Color.LightCyan;
            this.FormTienda.Controls.Add(this.panel2);
            this.FormTienda.Controls.Add(this.label17);
            this.FormTienda.Controls.Add(this.label16);
            this.FormTienda.Controls.Add(this.listBox2);
            this.FormTienda.Controls.Add(this.button15);
            this.FormTienda.Controls.Add(this.cantidad);
            this.FormTienda.Controls.Add(this.label24);
            this.FormTienda.Controls.Add(this.label22);
            this.FormTienda.Controls.Add(this.label15);
            this.FormTienda.Controls.Add(this.label21);
            this.FormTienda.Controls.Add(this.nombrecliente);
            this.FormTienda.Controls.Add(this.label13);
            this.FormTienda.Controls.Add(this.label14);
            this.FormTienda.Controls.Add(this.clienteid);
            this.FormTienda.Controls.Add(this.button2);
            this.FormTienda.Controls.Add(this.total);
            this.FormTienda.Controls.Add(this.idproducto);
            this.FormTienda.Controls.Add(this.precio);
            this.FormTienda.Controls.Add(this.existencia);
            this.FormTienda.Controls.Add(this.producto);
            this.FormTienda.Controls.Add(this.label6);
            this.FormTienda.Controls.Add(this.Existencias);
            this.FormTienda.Controls.Add(this.label8);
            this.FormTienda.Controls.Add(this.label3);
            this.FormTienda.Controls.Add(this.label4);
            this.FormTienda.Controls.Add(this.button6);
            this.FormTienda.Controls.Add(this.button4);
            this.FormTienda.Controls.Add(this.button5);
            this.FormTienda.Controls.Add(this.button3);
            this.FormTienda.Controls.Add(this.button1);
            this.FormTienda.Controls.Add(this.listBox1);
            this.FormTienda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FormTienda.Font = new System.Drawing.Font("Segoe UI Emoji", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormTienda.Location = new System.Drawing.Point(391, 18);
            this.FormTienda.Name = "FormTienda";
            this.FormTienda.Size = new System.Drawing.Size(430, 357);
            this.FormTienda.TabIndex = 1;
            this.FormTienda.TabStop = false;
            this.FormTienda.Text = "Registro de Compra";
            this.FormTienda.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel2.Controls.Add(this.button16);
            this.panel2.Controls.Add(this.button14);
            this.panel2.Controls.Add(this.button13);
            this.panel2.Controls.Add(this.dataGridView2);
            this.panel2.Controls.Add(this.button12);
            this.panel2.Controls.Add(this.busqueda2);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(1, 56);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(428, 234);
            this.panel2.TabIndex = 14;
            this.panel2.Visible = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Aquamarine;
            this.button16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button16.BackgroundImage")));
            this.button16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(285, 14);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(28, 26);
            this.button16.TabIndex = 17;
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.LimeGreen;
            this.button14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button14.BackgroundImage")));
            this.button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(393, 201);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(31, 29);
            this.button14.TabIndex = 16;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.LimeGreen;
            this.button13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button13.BackgroundImage")));
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(406, 1);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(22, 21);
            this.button13.TabIndex = 15;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.LightSeaGreen;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.LawnGreen;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView2.ColumnHeadersHeight = 30;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDProductoDataGridViewTextBoxColumn,
            this.productoDataGridViewTextBoxColumn,
            this.precioDataGridViewTextBoxColumn,
            this.existenciasDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.consultaTiendaBindingSource;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.GridColor = System.Drawing.Color.Black;
            this.dataGridView2.Location = new System.Drawing.Point(4, 50);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowTemplate.ReadOnly = true;
            this.dataGridView2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.Size = new System.Drawing.Size(421, 148);
            this.dataGridView2.TabIndex = 13;
            this.dataGridView2.TabStop = false;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            this.dataGridView2.SelectionChanged += new System.EventHandler(this.dataGridView2_SelectionChanged);
            // 
            // iDProductoDataGridViewTextBoxColumn
            // 
            this.iDProductoDataGridViewTextBoxColumn.DataPropertyName = "ID_Producto";
            this.iDProductoDataGridViewTextBoxColumn.HeaderText = "ID_Producto";
            this.iDProductoDataGridViewTextBoxColumn.Name = "iDProductoDataGridViewTextBoxColumn";
            this.iDProductoDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDProductoDataGridViewTextBoxColumn.Width = 95;
            // 
            // productoDataGridViewTextBoxColumn
            // 
            this.productoDataGridViewTextBoxColumn.DataPropertyName = "Producto";
            this.productoDataGridViewTextBoxColumn.HeaderText = "Producto";
            this.productoDataGridViewTextBoxColumn.Name = "productoDataGridViewTextBoxColumn";
            this.productoDataGridViewTextBoxColumn.ReadOnly = true;
            this.productoDataGridViewTextBoxColumn.Width = 94;
            // 
            // precioDataGridViewTextBoxColumn
            // 
            this.precioDataGridViewTextBoxColumn.DataPropertyName = "Precio";
            this.precioDataGridViewTextBoxColumn.HeaderText = "Precio";
            this.precioDataGridViewTextBoxColumn.Name = "precioDataGridViewTextBoxColumn";
            this.precioDataGridViewTextBoxColumn.ReadOnly = true;
            this.precioDataGridViewTextBoxColumn.Width = 95;
            // 
            // existenciasDataGridViewTextBoxColumn
            // 
            this.existenciasDataGridViewTextBoxColumn.DataPropertyName = "Existencias";
            this.existenciasDataGridViewTextBoxColumn.HeaderText = "Existencias";
            this.existenciasDataGridViewTextBoxColumn.Name = "existenciasDataGridViewTextBoxColumn";
            this.existenciasDataGridViewTextBoxColumn.ReadOnly = true;
            this.existenciasDataGridViewTextBoxColumn.Width = 94;
            // 
            // consultaTiendaBindingSource
            // 
            this.consultaTiendaBindingSource.DataMember = "ConsultaTienda";
            this.consultaTiendaBindingSource.DataSource = this.bD_Ferreter�aDataSet1;
            // 
            // bD_Ferreter�aDataSet1
            // 
            this.bD_Ferreter�aDataSet1.DataSetName = "BD_Ferreter�aDataSet1";
            this.bD_Ferreter�aDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.DarkBlue;
            this.button12.FlatAppearance.BorderColor = System.Drawing.Color.LightCyan;
            this.button12.FlatAppearance.BorderSize = 3;
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Aquamarine;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Segoe UI Black", 9F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(4, 14);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(138, 26);
            this.button12.TabIndex = 14;
            this.button12.Text = "Buscar Productos:";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // busqueda2
            // 
            this.busqueda2.BackColor = System.Drawing.Color.LightCyan;
            this.busqueda2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.busqueda2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.busqueda2.Location = new System.Drawing.Point(142, 14);
            this.busqueda2.Multiline = true;
            this.busqueda2.Name = "busqueda2";
            this.busqueda2.Size = new System.Drawing.Size(106, 26);
            this.busqueda2.TabIndex = 12;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.DarkBlue;
            this.label20.Location = new System.Drawing.Point(264, 210);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(126, 15);
            this.label20.TabIndex = 2;
            this.label20.Text = "Seleccionar Producto";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkBlue;
            this.label5.Location = new System.Drawing.Point(313, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "Actualizar";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Ivory;
            this.label17.Font = new System.Drawing.Font("Verdana", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(292, 162);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(111, 14);
            this.label17.TabIndex = 21;
            this.label17.Text = "Montos:             ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Ivory;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(14, 162);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(278, 14);
            this.label16.TabIndex = 20;
            this.label16.Text = "Carro de compra:                                       ";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.Ivory;
            this.listBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 23;
            this.listBox2.Location = new System.Drawing.Point(295, 176);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(108, 92);
            this.listBox2.TabIndex = 19;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.MintCream;
            this.button15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button15.BackgroundImage")));
            this.button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button15.FlatAppearance.BorderColor = System.Drawing.Color.Aqua;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.Black;
            this.button15.Location = new System.Drawing.Point(20, 67);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(61, 52);
            this.button15.TabIndex = 15;
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // cantidad
            // 
            this.cantidad.BackColor = System.Drawing.Color.Ivory;
            this.cantidad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cantidad.Location = new System.Drawing.Point(303, 74);
            this.cantidad.Multiline = true;
            this.cantidad.Name = "cantidad";
            this.cantidad.Size = new System.Drawing.Size(37, 32);
            this.cantidad.TabIndex = 18;
            this.cantidad.TextChanged += new System.EventHandler(this.textBox3_TextChanged_1);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label24.Font = new System.Drawing.Font("Segoe UI Black", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.DarkBlue;
            this.label24.Location = new System.Drawing.Point(13, 322);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 15);
            this.label24.TabIndex = 17;
            this.label24.Text = "Regresar";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label22.Font = new System.Drawing.Font("Segoe UI Black", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.DarkBlue;
            this.label22.Location = new System.Drawing.Point(14, 122);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(76, 30);
            this.label22.TabIndex = 17;
            this.label22.Text = "Seleccionar\r\n  Producto";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label15.Font = new System.Drawing.Font("Segoe UI Black", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.DarkBlue;
            this.label15.Location = new System.Drawing.Point(343, 76);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 30);
            this.label15.TabIndex = 17;
            this.label15.Text = "Cantidad a\r\n  comprar";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label21.Font = new System.Drawing.Font("Segoe UI Black", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.DarkBlue;
            this.label21.Location = new System.Drawing.Point(346, 114);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(64, 30);
            this.label21.TabIndex = 17;
            this.label21.Text = "  A�adir \r\n al carrito";
            // 
            // nombrecliente
            // 
            this.nombrecliente.BackColor = System.Drawing.Color.LightCyan;
            this.nombrecliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nombrecliente.Enabled = false;
            this.nombrecliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombrecliente.ForeColor = System.Drawing.Color.Black;
            this.nombrecliente.Location = new System.Drawing.Point(78, 35);
            this.nombrecliente.Multiline = true;
            this.nombrecliente.Name = "nombrecliente";
            this.nombrecliente.Size = new System.Drawing.Size(149, 21);
            this.nombrecliente.TabIndex = 12;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.LightCyan;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(13, 35);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 21);
            this.label13.TabIndex = 11;
            this.label13.Text = "Cliente:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.LightCyan;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(227, 35);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 21);
            this.label14.TabIndex = 10;
            this.label14.Text = "ID:";
            // 
            // clienteid
            // 
            this.clienteid.BackColor = System.Drawing.Color.LightCyan;
            this.clienteid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clienteid.Enabled = false;
            this.clienteid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clienteid.ForeColor = System.Drawing.Color.Black;
            this.clienteid.Location = new System.Drawing.Point(258, 35);
            this.clienteid.Multiline = true;
            this.clienteid.Name = "clienteid";
            this.clienteid.Size = new System.Drawing.Size(132, 21);
            this.clienteid.TabIndex = 13;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.Ivory;
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 23;
            this.listBox1.Location = new System.Drawing.Point(16, 176);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(279, 92);
            this.listBox1.TabIndex = 16;
            // 
            // tabla_ClientesTableAdapter
            // 
            this.tabla_ClientesTableAdapter.ClearBeforeFill = true;
            // 
            // tablaProductosBindingSource
            // 
            this.tablaProductosBindingSource.DataMember = "TablaProductos";
            this.tablaProductosBindingSource.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // tablaProductosTableAdapter
            // 
            this.tablaProductosTableAdapter.ClearBeforeFill = true;
            // 
            // consultaTiendaTableAdapter
            // 
            this.consultaTiendaTableAdapter.ClearBeforeFill = true;
            // 
            // Pic_Salir
            // 
            this.Pic_Salir.BackColor = System.Drawing.Color.MistyRose;
            this.Pic_Salir.Image = ((System.Drawing.Image)(resources.GetObject("Pic_Salir.Image")));
            this.Pic_Salir.Location = new System.Drawing.Point(804, 0);
            this.Pic_Salir.Name = "Pic_Salir";
            this.Pic_Salir.Size = new System.Drawing.Size(18, 18);
            this.Pic_Salir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_Salir.TabIndex = 2;
            this.Pic_Salir.TabStop = false;
            this.Pic_Salir.Click += new System.EventHandler(this.Pic_Salir_Click);
            this.Pic_Salir.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pic_Salir_MouseDown);
            this.Pic_Salir.MouseEnter += new System.EventHandler(this.Pic_Salir_MouseEnter);
            this.Pic_Salir.MouseLeave += new System.EventHandler(this.Pic_Salir_MouseLeave);
            // 
            // Pic_Minimizar
            // 
            this.Pic_Minimizar.BackColor = System.Drawing.Color.LightYellow;
            this.Pic_Minimizar.Image = ((System.Drawing.Image)(resources.GetObject("Pic_Minimizar.Image")));
            this.Pic_Minimizar.Location = new System.Drawing.Point(786, 0);
            this.Pic_Minimizar.Name = "Pic_Minimizar";
            this.Pic_Minimizar.Size = new System.Drawing.Size(18, 18);
            this.Pic_Minimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_Minimizar.TabIndex = 2;
            this.Pic_Minimizar.TabStop = false;
            this.Pic_Minimizar.Click += new System.EventHandler(this.Pic_Minimizar_Click);
            this.Pic_Minimizar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pic_Minimizar_MouseDown);
            this.Pic_Minimizar.MouseEnter += new System.EventHandler(this.Pic_Minimizar_MouseEnter);
            this.Pic_Minimizar.MouseLeave += new System.EventHandler(this.Pic_Minimizar_MouseLeave);
            // 
            // Tienda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.ClientSize = new System.Drawing.Size(835, 392);
            this.Controls.Add(this.Pic_Minimizar);
            this.Controls.Add(this.Pic_Salir);
            this.Controls.Add(this.FormCliente);
            this.Controls.Add(this.FormTienda);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Tienda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tienda";
            this.Load += new System.EventHandler(this.Tienda_Load);
            this.FormCliente.ResumeLayout(false);
            this.FormCliente.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaClientesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_Ferreter�aDataSet)).EndInit();
            this.FormTienda.ResumeLayout(false);
            this.FormTienda.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaTiendaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_Ferreter�aDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaProductosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Salir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Minimizar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox FormCliente;
        private System.Windows.Forms.Button BTN_ComenzarVenta;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private BD_Ferreter�aDataSet bD_Ferreter�aDataSet;
        private System.Windows.Forms.BindingSource tablaClientesBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.Tabla_ClientesTableAdapter tabla_ClientesTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDClienteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clienteDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox busqueda;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox cliente;
        private System.Windows.Forms.TextBox idcliente;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label Existencias;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox producto;
        private System.Windows.Forms.TextBox existencia;
        private System.Windows.Forms.TextBox precio;
        private System.Windows.Forms.TextBox idproducto;
        private System.Windows.Forms.TextBox total;
        private System.Windows.Forms.GroupBox FormTienda;
        private System.Windows.Forms.TextBox nombrecliente;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox clienteid;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox busqueda2;
        private System.Windows.Forms.BindingSource tablaProductosBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.TablaProductosTableAdapter tablaProductosTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDProductoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn precioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn existenciasDataGridViewTextBoxColumn;
        private BD_Ferreter�aDataSet1 bD_Ferreter�aDataSet1;
        private System.Windows.Forms.BindingSource consultaTiendaBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSet1TableAdapters.ConsultaTiendaTableAdapter consultaTiendaTableAdapter;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox cantidad;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox Pic_Salir;
        private System.Windows.Forms.PictureBox Pic_Minimizar;
        private System.Windows.Forms.Label label7;
    }
}