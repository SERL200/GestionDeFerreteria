namespace WindowsApplication1
{
    partial class Menu_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu_Principal));
            this.BTN_Consulta = new System.Windows.Forms.Button();
            this.BTN_Tienda = new System.Windows.Forms.Button();
            this.BTN_Admin = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Pic_Salir = new System.Windows.Forms.PictureBox();
            this.Pic_Minimizar = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Btn_Tema = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Salir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Minimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BTN_Consulta
            // 
            this.BTN_Consulta.BackColor = System.Drawing.Color.Beige;
            this.BTN_Consulta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BTN_Consulta.BackgroundImage")));
            this.BTN_Consulta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BTN_Consulta.Enabled = false;
            this.BTN_Consulta.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.BTN_Consulta.FlatAppearance.BorderSize = 3;
            this.BTN_Consulta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.BTN_Consulta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGoldenrod;
            this.BTN_Consulta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Consulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Consulta.Location = new System.Drawing.Point(407, 77);
            this.BTN_Consulta.Name = "BTN_Consulta";
            this.BTN_Consulta.Size = new System.Drawing.Size(146, 130);
            this.BTN_Consulta.TabIndex = 6;
            this.BTN_Consulta.UseVisualStyleBackColor = false;
            this.BTN_Consulta.Click += new System.EventHandler(this.BTN_Consulta_Click);
            // 
            // BTN_Tienda
            // 
            this.BTN_Tienda.BackColor = System.Drawing.Color.LightCyan;
            this.BTN_Tienda.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BTN_Tienda.BackgroundImage")));
            this.BTN_Tienda.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BTN_Tienda.Enabled = false;
            this.BTN_Tienda.FlatAppearance.BorderColor = System.Drawing.Color.DarkGreen;
            this.BTN_Tienda.FlatAppearance.BorderSize = 3;
            this.BTN_Tienda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.BTN_Tienda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.BTN_Tienda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Tienda.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Tienda.Location = new System.Drawing.Point(16, 78);
            this.BTN_Tienda.Name = "BTN_Tienda";
            this.BTN_Tienda.Size = new System.Drawing.Size(146, 131);
            this.BTN_Tienda.TabIndex = 5;
            this.BTN_Tienda.UseVisualStyleBackColor = false;
            this.BTN_Tienda.Click += new System.EventHandler(this.BTN_Tienda_Click);
            // 
            // BTN_Admin
            // 
            this.BTN_Admin.BackColor = System.Drawing.Color.Lavender;
            this.BTN_Admin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BTN_Admin.BackgroundImage")));
            this.BTN_Admin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BTN_Admin.Enabled = false;
            this.BTN_Admin.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.BTN_Admin.FlatAppearance.BorderSize = 3;
            this.BTN_Admin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.BTN_Admin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BTN_Admin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Admin.Location = new System.Drawing.Point(212, 77);
            this.BTN_Admin.Name = "BTN_Admin";
            this.BTN_Admin.Size = new System.Drawing.Size(146, 131);
            this.BTN_Admin.TabIndex = 4;
            this.BTN_Admin.UseVisualStyleBackColor = false;
            this.BTN_Admin.Click += new System.EventHandler(this.BTN_Admin_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(146, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(270, 128);
            this.panel1.TabIndex = 7;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.MistyRose;
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(240, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(27, 24);
            this.button4.TabIndex = 9;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(216, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(25, 24);
            this.button2.TabIndex = 8;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.SeaGreen;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.LightGreen;
            this.textBox1.Location = new System.Drawing.Point(16, 70);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(163, 23);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = " ID";
            this.textBox1.Enter += new System.EventHandler(this.textBox1_Enter);
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese su identificaci�n";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MintCream;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(185, 70);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(29, 22);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.PaleTurquoise;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleTurquoise;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(445, 259);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(34, 32);
            this.button3.TabIndex = 8;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Maiandra GD", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 274);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 22);
            this.label2.TabIndex = 9;
            this.label2.Text = "label2";
            this.label2.Visible = false;
            // 
            // Pic_Salir
            // 
            this.Pic_Salir.BackColor = System.Drawing.Color.LightCoral;
            this.Pic_Salir.Image = ((System.Drawing.Image)(resources.GetObject("Pic_Salir.Image")));
            this.Pic_Salir.Location = new System.Drawing.Point(553, 0);
            this.Pic_Salir.Name = "Pic_Salir";
            this.Pic_Salir.Size = new System.Drawing.Size(25, 24);
            this.Pic_Salir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_Salir.TabIndex = 10;
            this.Pic_Salir.TabStop = false;
            this.Pic_Salir.Click += new System.EventHandler(this.Pic_Salir_Click);
            this.Pic_Salir.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pic_Salir_MouseDown);
            this.Pic_Salir.MouseEnter += new System.EventHandler(this.Pic_Salir_MouseEnter);
            this.Pic_Salir.MouseLeave += new System.EventHandler(this.Pic_Salir_MouseLeave);
            // 
            // Pic_Minimizar
            // 
            this.Pic_Minimizar.BackColor = System.Drawing.Color.SkyBlue;
            this.Pic_Minimizar.Image = ((System.Drawing.Image)(resources.GetObject("Pic_Minimizar.Image")));
            this.Pic_Minimizar.Location = new System.Drawing.Point(528, 0);
            this.Pic_Minimizar.Name = "Pic_Minimizar";
            this.Pic_Minimizar.Size = new System.Drawing.Size(25, 24);
            this.Pic_Minimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_Minimizar.TabIndex = 11;
            this.Pic_Minimizar.TabStop = false;
            this.Pic_Minimizar.Click += new System.EventHandler(this.Pic_Minimizar_Click);
            this.Pic_Minimizar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pic_Minimizar_MouseDown);
            this.Pic_Minimizar.MouseEnter += new System.EventHandler(this.Pic_Minimizar_MouseEnter);
            this.Pic_Minimizar.MouseLeave += new System.EventHandler(this.Pic_Minimizar_MouseLeave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Maiandra GD", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(485, 263);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 28);
            this.label3.TabIndex = 12;
            this.label3.Text = "Cambiar\r\nUsuario";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Maiandra GD", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(56, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 22);
            this.label4.TabIndex = 12;
            this.label4.Text = "Tienda";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Maiandra GD", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(212, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 22);
            this.label5.TabIndex = 12;
            this.label5.Text = "Administraci�n";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Maiandra GD", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(441, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 22);
            this.label6.TabIndex = 12;
            this.label6.Text = "Consulta";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Btn_Tema
            // 
            this.Btn_Tema.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Tema.BackgroundImage")));
            this.Btn_Tema.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_Tema.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Btn_Tema.FlatAppearance.BorderSize = 0;
            this.Btn_Tema.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.Btn_Tema.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gold;
            this.Btn_Tema.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Tema.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Tema.Location = new System.Drawing.Point(319, 259);
            this.Btn_Tema.Name = "Btn_Tema";
            this.Btn_Tema.Size = new System.Drawing.Size(34, 32);
            this.Btn_Tema.TabIndex = 8;
            this.Btn_Tema.UseVisualStyleBackColor = true;
            this.Btn_Tema.Click += new System.EventHandler(this.Btn_Tema_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Maiandra GD", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(359, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 28);
            this.label7.TabIndex = 12;
            this.label7.Text = "Cambiar\r\nTema";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(16, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(271, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // Menu_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(576, 303);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Pic_Minimizar);
            this.Controls.Add(this.Pic_Salir);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Btn_Tema);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.BTN_Consulta);
            this.Controls.Add(this.BTN_Tienda);
            this.Controls.Add(this.BTN_Admin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Menu_Principal";
            this.Opacity = 0.98D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu_Principal";
            this.Load += new System.EventHandler(this.Menu_Principal_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Salir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Minimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTN_Consulta;
        private System.Windows.Forms.Button BTN_Tienda;
        private System.Windows.Forms.Button BTN_Admin;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox Pic_Salir;
        private System.Windows.Forms.PictureBox Pic_Minimizar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Btn_Tema;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}