using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
namespace WindowsApplication1
{
    public partial class Menu_Principal : Form
    {
        string guardaid = "";
        string idrol="";
        string nombre = "";
        string rolnombre = "";
        int Tema = 0;
        public Menu_Principal()
        {
            InitializeComponent();
            
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\BD Ferreter�a.mdb");
        //Utilizar el de abajo (cambiar ruta)
        //OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Samuel\Desktop\Proyecto Ferreteria\GestionDeFerreteria\GestionDeFerreteria\BD Ferreter�a.mdb");
        public void identificacion()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT TablaTrabajadores.Trabajador, TablaTrabajadores.ID_Rol, TablaRoles.Rol, TablaRoles.ID_Rol FROM TablaRoles INNER JOIN TablaTrabajadores ON TablaRoles.ID_Rol = TablaTrabajadores.ID_Rol WHERE TablaTrabajadores.ID_Trabajador='" +textBox1.Text+ "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            bindingSource1.DataSource = dt;
            con.Close();
            nombre = dt.Rows[0][0].ToString();
            rolnombre = dt.Rows[0][2].ToString();
            idrol = dt.Rows[0][3].ToString();
            string bienvenida=("Bienvenido " + nombre + "\nHas ingresado con el ID: " + textBox1.Text + "\nTu rol es: " + rolnombre);
            MessageBox.Show(bienvenida);
        }
        private void BTN_Tienda_Click(object sender, EventArgs e)
        {
            Tienda Tienda = new Tienda(guardaid);
            Tienda.ShowDialog();
        }

        private void BTN_Admin_Click(object sender, EventArgs e)
        {
            Administracion Administracion = new Administracion();
            Administracion.ShowDialog();
        }

        private void BTN_Consulta_Click(object sender, EventArgs e)
        {
            Consultas Consultas = new Consultas();
            Consultas.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                identificacion();
                if (rolnombre == "Administrador")
                {
                    BTN_Admin.Enabled = true;
                    BTN_Consulta.Enabled = true;
                    BTN_Tienda.Enabled = true;
                }
                else if (rolnombre=="Gerente")
                {
                    BTN_Admin.Enabled = false;
                    BTN_Consulta.Enabled = true;
                    BTN_Tienda.Enabled = true;
                }
                else if (rolnombre=="Cajero")
                {
                    BTN_Admin.Enabled = false;
                    BTN_Consulta.Enabled = false;
                    BTN_Tienda.Enabled = true;
                }

                guardaid = textBox1.Text;
                label2.Visible = true;
                label2.Text = "Sesi�n iniciada por: "+nombre;
                button4.Visible = false; button4.Enabled = false;
                button2.Visible = true; button2.Enabled = true;
                button3.Visible = true; button3.Enabled = true;
                Pic_Salir.Visible = true; Pic_Salir.Enabled = true;
                Pic_Minimizar.Visible = true; Pic_Minimizar.Enabled = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
                
                /*          TEMA OSCURO         */
                //label7.Visible = true;
                //Btn_Tema.Visible = true;
                
                
                button2.Left = 240;
                panel1.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Identificaci�n inv�lida, verifique sus datos. " + ex.Message);

                
            }
            textBox1.Text = " ID";
            textBox1.UseSystemPasswordChar = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Show();
        }

        private void Menu_Principal_Load(object sender, EventArgs e)
        {
            button2.Visible = false; button2.Enabled = false;
            button3.Visible = false; button3.Enabled = false;
            Pic_Salir.Visible = false; Pic_Salir.Enabled = false;
            Pic_Minimizar.Visible = false; Pic_Minimizar.Enabled = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            Btn_Tema.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == " ID")
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Aquamarine;
                textBox1.UseSystemPasswordChar = true;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = " ID";
                textBox1.ForeColor = Color.LightGreen;
                textBox1.UseSystemPasswordChar = false;
            }
        }

        private void Pic_Salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Pic_Minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

        private void Pic_Salir_MouseEnter(object sender, EventArgs e)
        {
            Pic_Salir.BackColor = Color.Red;

        }

        private void Pic_Minimizar_MouseEnter(object sender, EventArgs e)
        {

            Pic_Minimizar.BackColor = Color.DodgerBlue;
        }

        private void Pic_Salir_MouseDown(object sender, MouseEventArgs e)
        {
            Pic_Salir.BackColor = Color.Crimson;
        }

        private void Pic_Minimizar_MouseDown(object sender, MouseEventArgs e)
        {
            Pic_Minimizar.BackColor = Color.SteelBlue;
        }

        private void Pic_Salir_MouseLeave(object sender, EventArgs e)
        {
            if (Tema == 0)
            { Pic_Salir.BackColor = Color.LightCoral; }
            else
            { Pic_Salir.BackColor = Color.Black; }
            
        }

        private void Pic_Minimizar_MouseLeave(object sender, EventArgs e)
        {
            if (Tema == 0)
            { Pic_Minimizar.BackColor = Color.SkyBlue; }
            else
            { Pic_Minimizar.BackColor = Color.Black; }
                 
        }

        private void Btn_Tema_Click(object sender, EventArgs e)
        {

            if (Tema == 0)
            {
                BackColor = Color.Black;
                label2.ForeColor = Color.White;
                label3.ForeColor = Color.White;
                label4.ForeColor = Color.White;
                label5.ForeColor = Color.White;
                label6.ForeColor = Color.White;
                label7.ForeColor = Color.White;
                BTN_Tienda.BackColor = Color.Black;
                BTN_Admin.BackColor = Color.Black;
                BTN_Consulta.BackColor = Color.Black;
                Pic_Salir.BackColor = Color.Black;
                Pic_Minimizar.BackColor = Color.Black;
                Opacity = .85;
                Tema = 1;
            }
            else
            {
                BackColor = Color.MintCream;
                label2.ForeColor = Color.Black;
                label3.ForeColor = Color.Black;
                label4.ForeColor = Color.Black;
                label5.ForeColor = Color.Black;
                label6.ForeColor = Color.Black;
                label7.ForeColor = Color.Black;
                BTN_Tienda.BackColor = Color.LightCyan;
                BTN_Admin.BackColor = Color.Lavender;
                BTN_Consulta.BackColor = Color.Beige;
                Pic_Salir.BackColor = Color.LightCoral;
                Pic_Minimizar.BackColor = Color.SkyBlue;
                Opacity = .98;
                Tema = 0;
            }
        }
    }
}