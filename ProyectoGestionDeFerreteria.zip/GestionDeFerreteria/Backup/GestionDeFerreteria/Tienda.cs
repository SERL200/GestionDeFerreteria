using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsApplication1
{
    public partial class Tienda : Form
    {
        public Tienda(string guardaid)
        {
            InitializeComponent();
            this.guardaid = guardaid; 
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\BD Ferreter�a.mdb");
        //Utilizar el de abajo (cambiar ruta)
        //OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Cris\Documents\Visual Studio 2005\Projects\GestionDeFerreteria\GestionDeFerreteria\BD Ferreter�a.mdb");
        int calcutotal;
        string cantidadguardada = "";
        string nfactura = ""; 
        string descripcion="";
        string guardaid;
        public void refrescarclientes()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Tabla_Clientes";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tablaClientesBindingSource.DataSource = dt;
            dataGridView1.DataSource = dt;  
            con.Close();
        }
        public void refrescartienda () {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT TablaProductos.ID_Producto, TablaProductos.Producto, TablaProductos.Precio, TablaProductos.Existencias FROM TablaProductos";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dataGridView2.DataSource = dt;
            con.Close();
            
        }
        private void BTN_ComenzarVenta_Click(object sender, EventArgs e)
        {
            FormCliente.Hide();
            FormTienda.Show();
            refrescartienda();
            clienteid.Text=textBox1.Text;
            nombrecliente.Text = textBox2.Text;
            //idclientext=
            //clientext = textBox2.Text;

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (cantidad.Text == "")
            {
                MessageBox.Show("Debe llenar este campo con un numero", "Ingrese cantidad");
            }
            else if (Convert.ToInt32(cantidad.Text) > Convert.ToInt32(existencia.Text))
            {
                MessageBox.Show("La cantidad supera el limite de existencias de este producto", "Limite de existencias");
            }
            else
            {
                int monto = Convert.ToInt32(precio.Text) * Convert.ToInt32(cantidad.Text);
                descripcion += producto.Text + " x" + cantidad.Text+ " ";
                listBox1.Items.Add(producto.Text + " x" + cantidad.Text);
                listBox2.Items.Add(monto + "$");
                calcutotal += monto;
                total.Text = Convert.ToString(calcutotal) + "$";
                cantidadguardada = cantidad.Text;
                int resta=Convert.ToInt32(existencia.Text) - Convert.ToInt32(cantidad.Text);
                cantidad.Text = "";
                existencia.Text = Convert.ToString(resta);
            }
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormCliente.Show();
            FormTienda.Hide();
        }

        private void Tienda_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bD_Ferreter�aDataSet1.ConsultaTienda' table. You can move, or remove it, as needed.
            this.consultaTiendaTableAdapter.Fill(this.bD_Ferreter�aDataSet1.ConsultaTienda);
            // TODO: This line of code loads data into the 'bD_Ferreter�aDataSet.TablaProductos' table. You can move, or remove it, as needed.
            this.tablaProductosTableAdapter.Fill(this.bD_Ferreter�aDataSet.TablaProductos);
            // TODO: This line of code loads data into the 'bD_Ferreter�aDataSet.Tabla_Clientes' table. You can move, or remove it, as needed.
            this.tabla_ClientesTableAdapter.Fill(this.bD_Ferreter�aDataSet.Tabla_Clientes);
            refrescarclientes();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into Tabla_Clientes (ID_Cliente, Cliente) values ('" + idcliente.Text + "','" + cliente.Text + "')";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Insertado con exito");
                refrescarclientes();
            }
            catch (Exception errordato)
            {
                MessageBox.Show("Asegurese de que ninguno de los datos se encuentren vac�os.\nVerifique que los campos tengan los datos correctos y no existan ID repetidos", "Error de datos insertar");

            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel1.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel1.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from Tabla_Clientes where ID_Cliente='" + busqueda.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch {
                MessageBox.Show("Cliente no encontrado");
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //textBox2.Text=dataGridView1.CurrentRow.Cells[0].Value.ToString();
            //textBox1.Text= dataGridView1.CurrentRow.Cells[0].Value.ToString();
            
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            textBox2.Text=dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox1.Text= dataGridView1.CurrentRow.Cells[0].Value.ToString();
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            refrescarclientes();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            panel2.Hide();
            //con.Close();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            panel2.Hide();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            panel2.Show();
        }

        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
            idproducto.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            producto.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString(); 
            precio.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString(); 
            existencia.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString(); 
            
        }

        private void button12_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT TablaProductos.ID_Producto, TablaProductos.Producto, TablaProductos.Precio, TablaProductos.Existencias FROM TablaProductos where TablaProductos.Producto='" + busqueda2.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);              
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                con.Close();
                
            }
            catch
            {
                MessageBox.Show("Producto no encontrado");
                con.Close();
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            refrescartienda();
        }

        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count > 0)
            {

                if (MessageBox.Show("Desea confirmar su compra? ", "Confirmar compra", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Random r = new Random(); 
                    nfactura=Convert.ToString(r.Next(10000, 99999));
                    MessageBox.Show("Compra exitosa" + "\nID Transacci�n: " + nfactura + "\nMonto total=" + total.Text + "\nGracias por su compra!", "Factura", MessageBoxButtons.OK);
                   
                   try
                   {
                        con.Open();
                        OleDbCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "insert into TablaVentas (ID_Factura,ID_Cliente, ID_Trabajador, Monto, Descripci�n) values ('" + nfactura + "','" + clienteid.Text + "',"+Convert.ToString(guardaid)+"," + "'"+total.Text+"','"+descripcion+ "')";
                        cmd.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("Factura "+nfactura+" guardada en base de datos con �xito");
                        
                    }
                    catch (Exception errordato)
                    {
                    MessageBox.Show("Fallo al guardar factura", "Error factura");

                    }
                    calcutotal = 0;
                    listBox1.Items.Clear();
                    listBox2.Items.Clear();
                    cantidad.Text = "";
                    total.Text = "";
                    descripcion = "";
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("La lista de compra aun se encuentra vacia", "Cancelar compra");
            }
            else if (MessageBox.Show("Desea cancelar su pedido?", "Cancelar compra", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                calcutotal = 0;
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                
                int suma = Convert.ToInt32(existencia.Text) + Convert.ToInt32(cantidadguardada);
                existencia.Text = Convert.ToString(suma);
                cantidadguardada = "";
                cantidad.Text = "";
                total.Text = "";
                descripcion = "";
            }
        }
    }
}