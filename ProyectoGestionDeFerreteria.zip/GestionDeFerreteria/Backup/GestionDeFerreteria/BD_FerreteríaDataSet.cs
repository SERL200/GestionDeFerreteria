﻿namespace WindowsApplication1 {


    partial class BD_FerreteríaDataSet
    {
        partial class TablaProductosDataTable
        {
        }
    }
}
