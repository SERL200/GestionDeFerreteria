using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsApplication1
{
    public partial class Consultas : Form
    {
        public Consultas()
        {
            InitializeComponent();
        }
        int eleccion = 0;
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\BD Ferreter�a.mdb");
        //Utilizar el de abajo (cambiar ruta)
        //OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Cris\Documents\Visual Studio 2005\Projects\GestionDeFerreteria\GestionDeFerreteria\BD Ferreter�a.mdb");
        public void consultaclientes()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Tabla_Clientes";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tabla.DataSource = dt;
            con.Close();
            
        }
        public void consultaproductos()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT TablaProductos.ID_Producto, TablaProductos.[ID Distribuidor], TablaProductos.Producto, TablaProductos.Precio, TablaProductos.Existencias, TablaDistribuidores.Distribuidor FROM TablaDistribuidores INNER JOIN TablaProductos ON TablaDistribuidores.ID_Distribuidor = TablaProductos.[ID Distribuidor]";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tabla.DataSource = dt;
            con.Close();
        }
        public void consultatrabajadores()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT TablaTrabajadores.ID_Trabajador, TablaTrabajadores.Trabajador, TablaTrabajadores.ID_Rol, TablaRoles.Rol FROM TablaRoles INNER JOIN TablaTrabajadores ON TablaRoles.ID_Rol = TablaTrabajadores.ID_Rol";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tabla.DataSource = dt;
            con.Close();
        }
        public void consultafacturas()
        {
            eleccion = 4;
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM TablaVentas";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tabla.DataSource = dt;
            con.Close();
        }
        public void busquedaproductos() { 
                        con.Open();
                        OleDbCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "SELECT TablaProductos.ID_Producto, TablaProductos.[ID Distribuidor], TablaProductos.Producto, TablaProductos.Precio, TablaProductos.Existencias, TablaDistribuidores.Distribuidor FROM TablaDistribuidores INNER JOIN TablaProductos ON TablaDistribuidores.ID_Distribuidor = TablaProductos.[ID Distribuidor] where TablaProductos.Producto = '" + busqueda.Text+"'";
                        cmd.ExecuteNonQuery();
                        DataTable dt = new DataTable();
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        da.Fill(dt);
                        tabla.DataSource = dt;
                        con.Close();
        }
        public void busquedatrabajadores() {
                        con.Open();
                        OleDbCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "SELECT TablaTrabajadores.ID_Trabajador, TablaTrabajadores.Trabajador, TablaTrabajadores.ID_Rol, TablaRoles.Rol FROM TablaRoles INNER JOIN TablaTrabajadores ON TablaRoles.ID_Rol = TablaTrabajadores.ID_Rol where TablaTrabajadores.Trabajador='"+busqueda.Text+"'";
                        cmd.ExecuteNonQuery();
                        DataTable dt = new DataTable();
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        da.Fill(dt);
                        tabla.DataSource = dt;
                        con.Close();
        }
        public void busquedaclientes(){
                        con.Open();
                        OleDbCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "select * from Tabla_Clientes where ID_Cliente='"+busqueda.Text+"'";
                        cmd.ExecuteNonQuery();
                        DataTable dt = new DataTable();
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        da.Fill(dt);
                        tabla.DataSource = dt;
                        con.Close();
        }
        public void busquedafacturas() {
            eleccion = 4;
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM TablaVentas where ID_Factura='" + busqueda.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tabla.DataSource = dt;
            con.Close();
        }
        
        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            consultaproductos();
            eleccion = 1;
        }

        private void trabajadoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            consultatrabajadores();
            eleccion = 2;
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            consultaclientes();
            eleccion = 3;
        }

        private void distribuidoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            consultafacturas();
            eleccion = 4;
        }

        private void busqueda_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                switch (eleccion)
                {
                    case 1:
                        busquedaproductos();
                        break;
                    case 2:
                        busquedatrabajadores();
                        break;
                    case 3:
                        busquedaclientes();           
                        break;
                    case 4:
                        busquedafacturas();
                        break;
                }
            }
            catch
            {
                MessageBox.Show("Elemento no encontrado");
            }
        }
    }
}