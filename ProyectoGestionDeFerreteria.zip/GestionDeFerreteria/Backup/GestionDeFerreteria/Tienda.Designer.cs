namespace WindowsApplication1
{
    partial class Tienda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.FormCliente = new System.Windows.Forms.GroupBox();
            this.button11 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.cliente = new System.Windows.Forms.TextBox();
            this.idcliente = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDClienteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clienteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tablaClientesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD_Ferreter�aDataSet = new WindowsApplication1.BD_Ferreter�aDataSet();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.busqueda = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BTN_ComenzarVenta = new System.Windows.Forms.Button();
            this.tabla_ClientesTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.Tabla_ClientesTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Existencias = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.producto = new System.Windows.Forms.TextBox();
            this.existencia = new System.Windows.Forms.TextBox();
            this.precio = new System.Windows.Forms.TextBox();
            this.idproducto = new System.Windows.Forms.TextBox();
            this.total = new System.Windows.Forms.TextBox();
            this.FormTienda = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.cantidad = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.nombrecliente = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.clienteid = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button16 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.iDProductoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.precioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.existenciasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.consultaTiendaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD_Ferreter�aDataSet1 = new WindowsApplication1.BD_Ferreter�aDataSet1();
            this.button12 = new System.Windows.Forms.Button();
            this.busqueda2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tablaProductosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tablaProductosTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.TablaProductosTableAdapter();
            this.consultaTiendaTableAdapter = new WindowsApplication1.BD_Ferreter�aDataSet1TableAdapters.ConsultaTiendaTableAdapter();
            this.FormCliente.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaClientesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_Ferreter�aDataSet)).BeginInit();
            this.FormTienda.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaTiendaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_Ferreter�aDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaProductosBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // FormCliente
            // 
            this.FormCliente.Controls.Add(this.button11);
            this.FormCliente.Controls.Add(this.panel1);
            this.FormCliente.Controls.Add(this.button10);
            this.FormCliente.Controls.Add(this.button9);
            this.FormCliente.Controls.Add(this.dataGridView1);
            this.FormCliente.Controls.Add(this.textBox2);
            this.FormCliente.Controls.Add(this.busqueda);
            this.FormCliente.Controls.Add(this.textBox1);
            this.FormCliente.Controls.Add(this.label2);
            this.FormCliente.Controls.Add(this.label9);
            this.FormCliente.Controls.Add(this.label1);
            this.FormCliente.Controls.Add(this.BTN_ComenzarVenta);
            this.FormCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormCliente.Location = new System.Drawing.Point(12, 316);
            this.FormCliente.Name = "FormCliente";
            this.FormCliente.Size = new System.Drawing.Size(532, 243);
            this.FormCliente.TabIndex = 0;
            this.FormCliente.TabStop = false;
            this.FormCliente.Text = "Formulario Cliente";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(10, 149);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(93, 31);
            this.button11.TabIndex = 11;
            this.button11.Text = "Refrescar";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.cliente);
            this.panel1.Controls.Add(this.idcliente);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Location = new System.Drawing.Point(126, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(280, 188);
            this.panel1.TabIndex = 5;
            this.panel1.Visible = false;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(8, 147);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(93, 31);
            this.button8.TabIndex = 9;
            this.button8.Text = "Cerrar";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // cliente
            // 
            this.cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cliente.Location = new System.Drawing.Point(84, 92);
            this.cliente.Name = "cliente";
            this.cliente.Size = new System.Drawing.Size(181, 26);
            this.cliente.TabIndex = 7;
            // 
            // idcliente
            // 
            this.idcliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idcliente.Location = new System.Drawing.Point(84, 45);
            this.idcliente.Name = "idcliente";
            this.idcliente.Size = new System.Drawing.Size(181, 26);
            this.idcliente.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(8, 92);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 20);
            this.label10.TabIndex = 6;
            this.label10.Text = "Cliente:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(67, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(140, 20);
            this.label12.TabIndex = 5;
            this.label12.Text = "Agregar clientes";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(45, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 20);
            this.label11.TabIndex = 5;
            this.label11.Text = "ID:";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(174, 124);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(93, 54);
            this.button7.TabIndex = 4;
            this.button7.Text = "Agregar Cliente\r\n";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(441, 21);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(84, 31);
            this.button10.TabIndex = 10;
            this.button10.Text = "Buscar";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(10, 183);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(93, 54);
            this.button9.TabIndex = 6;
            this.button9.Text = "Agregar nuevo";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDClienteDataGridViewTextBoxColumn,
            this.clienteDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tablaClientesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(283, 55);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(242, 149);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // iDClienteDataGridViewTextBoxColumn
            // 
            this.iDClienteDataGridViewTextBoxColumn.DataPropertyName = "ID_Cliente";
            this.iDClienteDataGridViewTextBoxColumn.HeaderText = "ID_Cliente";
            this.iDClienteDataGridViewTextBoxColumn.Name = "iDClienteDataGridViewTextBoxColumn";
            // 
            // clienteDataGridViewTextBoxColumn
            // 
            this.clienteDataGridViewTextBoxColumn.DataPropertyName = "Cliente";
            this.clienteDataGridViewTextBoxColumn.HeaderText = "Cliente";
            this.clienteDataGridViewTextBoxColumn.Name = "clienteDataGridViewTextBoxColumn";
            // 
            // tablaClientesBindingSource
            // 
            this.tablaClientesBindingSource.DataMember = "Tabla_Clientes";
            this.tablaClientesBindingSource.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // bD_Ferreter�aDataSet
            // 
            this.bD_Ferreter�aDataSet.DataSetName = "BD_Ferreter�aDataSet";
            this.bD_Ferreter�aDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBox2
            // 
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tablaClientesBindingSource, "Cliente", true));
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tablaClientesBindingSource, "ID_Cliente", true));
            this.textBox2.Enabled = false;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(82, 115);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(181, 26);
            this.textBox2.TabIndex = 3;
            // 
            // busqueda
            // 
            this.busqueda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.busqueda.Location = new System.Drawing.Point(283, 23);
            this.busqueda.Name = "busqueda";
            this.busqueda.Size = new System.Drawing.Size(146, 26);
            this.busqueda.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tablaClientesBindingSource, "ID_Cliente", true));
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tablaClientesBindingSource, "ID_Cliente", true));
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(82, 71);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(181, 26);
            this.textBox1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Cliente:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(149, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 20);
            this.label9.TabIndex = 2;
            this.label9.Text = "Buscar cliente:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "ID:";
            // 
            // BTN_ComenzarVenta
            // 
            this.BTN_ComenzarVenta.Location = new System.Drawing.Point(170, 182);
            this.BTN_ComenzarVenta.Name = "BTN_ComenzarVenta";
            this.BTN_ComenzarVenta.Size = new System.Drawing.Size(93, 57);
            this.BTN_ComenzarVenta.TabIndex = 0;
            this.BTN_ComenzarVenta.Text = "Comenzar Venta\r\n";
            this.BTN_ComenzarVenta.UseVisualStyleBackColor = true;
            this.BTN_ComenzarVenta.Click += new System.EventHandler(this.BTN_ComenzarVenta_Click);
            // 
            // tabla_ClientesTableAdapter
            // 
            this.tabla_ClientesTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(490, 259);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 29);
            this.button1.TabIndex = 0;
            this.button1.Text = "Vender\r\n";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(179, 224);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(78, 29);
            this.button3.TabIndex = 0;
            this.button3.Text = "Agregar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(398, 259);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(86, 29);
            this.button5.TabIndex = 0;
            this.button5.Text = "Cancelar";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(6, 259);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 29);
            this.button2.TabIndex = 0;
            this.button2.Text = "Volver\r\n";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(-334, 196);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 29);
            this.button4.TabIndex = 0;
            this.button4.Text = "Volver\r\n";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(-334, 247);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(87, 29);
            this.button6.TabIndex = 0;
            this.button6.Text = "Volver\r\n";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Producto:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(39, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Precio:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(431, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(142, 20);
            this.label7.TabIndex = 2;
            this.label7.Text = "Lista de compra:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(-4, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 20);
            this.label8.TabIndex = 2;
            this.label8.Text = "ID Producto:";
            // 
            // Existencias
            // 
            this.Existencias.AutoSize = true;
            this.Existencias.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Existencias.Location = new System.Drawing.Point(-2, 155);
            this.Existencias.Name = "Existencias";
            this.Existencias.Size = new System.Drawing.Size(105, 20);
            this.Existencias.TabIndex = 2;
            this.Existencias.Text = "Existencias:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(255, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Total:";
            // 
            // producto
            // 
            this.producto.Enabled = false;
            this.producto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.producto.Location = new System.Drawing.Point(103, 120);
            this.producto.Name = "producto";
            this.producto.Size = new System.Drawing.Size(154, 26);
            this.producto.TabIndex = 3;
            // 
            // existencia
            // 
            this.existencia.Enabled = false;
            this.existencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.existencia.Location = new System.Drawing.Point(103, 152);
            this.existencia.Name = "existencia";
            this.existencia.Size = new System.Drawing.Size(64, 26);
            this.existencia.TabIndex = 3;
            // 
            // precio
            // 
            this.precio.Enabled = false;
            this.precio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.precio.Location = new System.Drawing.Point(102, 184);
            this.precio.Name = "precio";
            this.precio.Size = new System.Drawing.Size(65, 26);
            this.precio.TabIndex = 3;
            this.precio.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // idproducto
            // 
            this.idproducto.Enabled = false;
            this.idproducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idproducto.Location = new System.Drawing.Point(103, 88);
            this.idproducto.Name = "idproducto";
            this.idproducto.Size = new System.Drawing.Size(64, 26);
            this.idproducto.TabIndex = 3;
            this.idproducto.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // total
            // 
            this.total.Enabled = false;
            this.total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total.Location = new System.Drawing.Point(306, 265);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(86, 26);
            this.total.TabIndex = 3;
            this.total.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // FormTienda
            // 
            this.FormTienda.Controls.Add(this.panel2);
            this.FormTienda.Controls.Add(this.label17);
            this.FormTienda.Controls.Add(this.label16);
            this.FormTienda.Controls.Add(this.listBox2);
            this.FormTienda.Controls.Add(this.cantidad);
            this.FormTienda.Controls.Add(this.label15);
            this.FormTienda.Controls.Add(this.button15);
            this.FormTienda.Controls.Add(this.nombrecliente);
            this.FormTienda.Controls.Add(this.label13);
            this.FormTienda.Controls.Add(this.label14);
            this.FormTienda.Controls.Add(this.clienteid);
            this.FormTienda.Controls.Add(this.total);
            this.FormTienda.Controls.Add(this.idproducto);
            this.FormTienda.Controls.Add(this.precio);
            this.FormTienda.Controls.Add(this.existencia);
            this.FormTienda.Controls.Add(this.producto);
            this.FormTienda.Controls.Add(this.label6);
            this.FormTienda.Controls.Add(this.Existencias);
            this.FormTienda.Controls.Add(this.label8);
            this.FormTienda.Controls.Add(this.label7);
            this.FormTienda.Controls.Add(this.label3);
            this.FormTienda.Controls.Add(this.label4);
            this.FormTienda.Controls.Add(this.button6);
            this.FormTienda.Controls.Add(this.button4);
            this.FormTienda.Controls.Add(this.button2);
            this.FormTienda.Controls.Add(this.button5);
            this.FormTienda.Controls.Add(this.button3);
            this.FormTienda.Controls.Add(this.button1);
            this.FormTienda.Controls.Add(this.listBox1);
            this.FormTienda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormTienda.Location = new System.Drawing.Point(12, 12);
            this.FormTienda.Name = "FormTienda";
            this.FormTienda.Size = new System.Drawing.Size(583, 298);
            this.FormTienda.TabIndex = 1;
            this.FormTienda.TabStop = false;
            this.FormTienda.Text = "Formulario Tienda";
            this.FormTienda.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(474, 130);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(62, 16);
            this.label17.TabIndex = 21;
            this.label17.Text = "Montos:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(260, 130);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(128, 16);
            this.label16.TabIndex = 20;
            this.label16.Text = "Carro de compra:";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 20;
            this.listBox2.Location = new System.Drawing.Point(477, 148);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(100, 104);
            this.listBox2.TabIndex = 19;
            // 
            // cantidad
            // 
            this.cantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cantidad.Location = new System.Drawing.Point(352, 101);
            this.cantidad.Name = "cantidad";
            this.cantidad.Size = new System.Drawing.Size(54, 26);
            this.cantidad.TabIndex = 18;
            this.cantidad.TextChanged += new System.EventHandler(this.textBox3_TextChanged_1);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(263, 104);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 20);
            this.label15.TabIndex = 17;
            this.label15.Text = "Cantidad:";
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(435, 19);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(138, 31);
            this.button15.TabIndex = 15;
            this.button15.Text = "Buscar producto";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // nombrecliente
            // 
            this.nombrecliente.Enabled = false;
            this.nombrecliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombrecliente.Location = new System.Drawing.Point(102, 60);
            this.nombrecliente.Name = "nombrecliente";
            this.nombrecliente.Size = new System.Drawing.Size(181, 26);
            this.nombrecliente.TabIndex = 12;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(36, 63);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 20);
            this.label13.TabIndex = 11;
            this.label13.Text = "Cliente:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(9, 31);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 20);
            this.label14.TabIndex = 10;
            this.label14.Text = "ID Cliente:";
            // 
            // clienteid
            // 
            this.clienteid.Enabled = false;
            this.clienteid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clienteid.Location = new System.Drawing.Point(102, 28);
            this.clienteid.Name = "clienteid";
            this.clienteid.Size = new System.Drawing.Size(181, 26);
            this.clienteid.TabIndex = 13;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(263, 149);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(208, 104);
            this.listBox1.TabIndex = 16;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button16);
            this.panel2.Controls.Add(this.button14);
            this.panel2.Controls.Add(this.button13);
            this.panel2.Controls.Add(this.dataGridView2);
            this.panel2.Controls.Add(this.button12);
            this.panel2.Controls.Add(this.busqueda2);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(40, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(428, 234);
            this.panel2.TabIndex = 14;
            this.panel2.Visible = false;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(334, 6);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(90, 31);
            this.button16.TabIndex = 17;
            this.button16.Text = "Refrescar";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(308, 201);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(110, 29);
            this.button14.TabIndex = 16;
            this.button14.Text = "Seleccionar";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(4, 201);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(87, 29);
            this.button13.TabIndex = 15;
            this.button13.Text = "Volver\r\n";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDProductoDataGridViewTextBoxColumn,
            this.productoDataGridViewTextBoxColumn,
            this.precioDataGridViewTextBoxColumn,
            this.existenciasDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.consultaTiendaBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(3, 39);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(421, 159);
            this.dataGridView2.TabIndex = 13;
            this.dataGridView2.SelectionChanged += new System.EventHandler(this.dataGridView2_SelectionChanged);
            // 
            // iDProductoDataGridViewTextBoxColumn
            // 
            this.iDProductoDataGridViewTextBoxColumn.DataPropertyName = "ID_Producto";
            this.iDProductoDataGridViewTextBoxColumn.HeaderText = "ID_Producto";
            this.iDProductoDataGridViewTextBoxColumn.Name = "iDProductoDataGridViewTextBoxColumn";
            // 
            // productoDataGridViewTextBoxColumn
            // 
            this.productoDataGridViewTextBoxColumn.DataPropertyName = "Producto";
            this.productoDataGridViewTextBoxColumn.HeaderText = "Producto";
            this.productoDataGridViewTextBoxColumn.Name = "productoDataGridViewTextBoxColumn";
            // 
            // precioDataGridViewTextBoxColumn
            // 
            this.precioDataGridViewTextBoxColumn.DataPropertyName = "Precio";
            this.precioDataGridViewTextBoxColumn.HeaderText = "Precio";
            this.precioDataGridViewTextBoxColumn.Name = "precioDataGridViewTextBoxColumn";
            // 
            // existenciasDataGridViewTextBoxColumn
            // 
            this.existenciasDataGridViewTextBoxColumn.DataPropertyName = "Existencias";
            this.existenciasDataGridViewTextBoxColumn.HeaderText = "Existencias";
            this.existenciasDataGridViewTextBoxColumn.Name = "existenciasDataGridViewTextBoxColumn";
            // 
            // consultaTiendaBindingSource
            // 
            this.consultaTiendaBindingSource.DataMember = "ConsultaTienda";
            this.consultaTiendaBindingSource.DataSource = this.bD_Ferreter�aDataSet1;
            // 
            // bD_Ferreter�aDataSet1
            // 
            this.bD_Ferreter�aDataSet1.DataSetName = "BD_Ferreter�aDataSet1";
            this.bD_Ferreter�aDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(259, 6);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(72, 31);
            this.button12.TabIndex = 14;
            this.button12.Text = "Buscar";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // busqueda2
            // 
            this.busqueda2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.busqueda2.Location = new System.Drawing.Point(147, 7);
            this.busqueda2.Name = "busqueda2";
            this.busqueda2.Size = new System.Drawing.Size(106, 26);
            this.busqueda2.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Buscar producto:";
            // 
            // tablaProductosBindingSource
            // 
            this.tablaProductosBindingSource.DataMember = "TablaProductos";
            this.tablaProductosBindingSource.DataSource = this.bD_Ferreter�aDataSet;
            // 
            // tablaProductosTableAdapter
            // 
            this.tablaProductosTableAdapter.ClearBeforeFill = true;
            // 
            // consultaTiendaTableAdapter
            // 
            this.consultaTiendaTableAdapter.ClearBeforeFill = true;
            // 
            // Tienda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 565);
            this.Controls.Add(this.FormCliente);
            this.Controls.Add(this.FormTienda);
            this.Name = "Tienda";
            this.Text = "Tienda";
            this.Load += new System.EventHandler(this.Tienda_Load);
            this.FormCliente.ResumeLayout(false);
            this.FormCliente.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaClientesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_Ferreter�aDataSet)).EndInit();
            this.FormTienda.ResumeLayout(false);
            this.FormTienda.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaTiendaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_Ferreter�aDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablaProductosBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox FormCliente;
        private System.Windows.Forms.Button BTN_ComenzarVenta;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private BD_Ferreter�aDataSet bD_Ferreter�aDataSet;
        private System.Windows.Forms.BindingSource tablaClientesBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.Tabla_ClientesTableAdapter tabla_ClientesTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDClienteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clienteDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox busqueda;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox cliente;
        private System.Windows.Forms.TextBox idcliente;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label Existencias;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox producto;
        private System.Windows.Forms.TextBox existencia;
        private System.Windows.Forms.TextBox precio;
        private System.Windows.Forms.TextBox idproducto;
        private System.Windows.Forms.TextBox total;
        private System.Windows.Forms.GroupBox FormTienda;
        private System.Windows.Forms.TextBox nombrecliente;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox clienteid;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox busqueda2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.BindingSource tablaProductosBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSetTableAdapters.TablaProductosTableAdapter tablaProductosTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDProductoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn precioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn existenciasDataGridViewTextBoxColumn;
        private BD_Ferreter�aDataSet1 bD_Ferreter�aDataSet1;
        private System.Windows.Forms.BindingSource consultaTiendaBindingSource;
        private WindowsApplication1.BD_Ferreter�aDataSet1TableAdapters.ConsultaTiendaTableAdapter consultaTiendaTableAdapter;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox cantidad;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label label17;
    }
}