using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsApplication1
{
    public partial class Administracion : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\BD Ferreter�a.mdb");
        //Utilizar el de abajo (cambiar ruta)
        //OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Cris\Documents\Visual Studio 2005\Projects\GestionDeFerreteria\GestionDeFerreteria\BD Ferreter�a.mdb");
        public Administracion()
        {
            InitializeComponent();
            
        }
        string combodistribuidores;
        string comborol;
        public void refrescarclientes() 
        { 
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Tabla_Clientes";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tablaClientesBindingSource.DataSource = dt;
            con.Close();
        }
        public void refrescarproductos()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT TablaProductos.ID_Producto, TablaProductos.[ID Distribuidor], TablaProductos.Producto, TablaProductos.Precio, TablaProductos.Existencias, TablaDistribuidores.Distribuidor FROM TablaDistribuidores INNER JOIN TablaProductos ON TablaDistribuidores.ID_Distribuidor = TablaProductos.[ID Distribuidor]";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            consultaProductosBindingSource.DataSource = dt;
            con.Close();
        }
        public void refrescartrabajadores()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT TablaTrabajadores.ID_Trabajador, TablaTrabajadores.Trabajador, TablaTrabajadores.ID_Rol, TablaRoles.Rol FROM TablaRoles INNER JOIN TablaTrabajadores ON TablaRoles.ID_Rol = TablaTrabajadores.ID_Rol";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            consultaTrabajadoresBindingSource.DataSource = dt;
            con.Close();
        }
        public void refrescardistribuidores()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from TablaDistribuidores";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tablaDistribuidoresBindingSource.DataSource = dt;
            con.Close();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            consultaProductosBindingSource.MoveNext();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTrabajadores.Hide();
            FormClientes.Hide();
            FormDistribuidores.Hide();
            FormProductos.Show();
               
        }

        private void trabajadoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormProductos.Hide();
            FormClientes.Hide();
            FormDistribuidores.Hide();
            FormTrabajadores.Show();  
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTrabajadores.Hide();
            FormProductos.Hide();
            FormDistribuidores.Hide();
            FormClientes.Show();
        }

        private void FormClientes_Enter(object sender, EventArgs e)
        {

        }

        private void Administracion_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bD_Ferreter�aDataSet.TablaRoles' table. You can move, or remove it, as needed.
            this.tablaRolesTableAdapter.Fill(this.bD_Ferreter�aDataSet.TablaRoles);
            // TODO: This line of code loads data into the 'bD_Ferreter�aDataSet.TablaDistribuidores' table. You can move, or remove it, as needed.
            this.tablaDistribuidoresTableAdapter.Fill(this.bD_Ferreter�aDataSet.TablaDistribuidores);
            // TODO: This line of code loads data into the 'bD_Ferreter�aDataSet.ConsultaTrabajadores' table. You can move, or remove it, as needed.
            this.consultaTrabajadoresTableAdapter.Fill(this.bD_Ferreter�aDataSet.ConsultaTrabajadores);
            // TODO: This line of code loads data into the 'bD_Ferreter�aDataSet.ConsultaProductos' table. You can move, or remove it, as needed.
            this.consultaProductosTableAdapter.Fill(this.bD_Ferreter�aDataSet.ConsultaProductos);
            // TODO: This line of code loads data into the 'bD_Ferreter�aDataSet.Tabla_Clientes' table. You can move, or remove it, as needed.
            this.tabla_ClientesTableAdapter.Fill(this.bD_Ferreter�aDataSet.Tabla_Clientes);

        }

        

        private void button11_Click(object sender, EventArgs e)
        {
            tablaClientesBindingSource.MovePrevious();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            tablaClientesBindingSource.MoveNext();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            try
            {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Tabla_Clientes (ID_Cliente, Cliente) values ('" + idcliente.Text + "','" + cliente.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Insertado con exito");            
            refrescarclientes();
            }
            catch (Exception errordato)
            {
                MessageBox.Show("Asegurese de que ninguno de los datos se encuentren vac�os.\nVerifique que los campos tengan los datos correctos ", "Error de datos insertar");

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            consultaTrabajadoresBindingSource.MovePrevious();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            consultaTrabajadoresBindingSource.MoveNext();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            consultaProductosBindingSource.MovePrevious();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update Tabla_Clientes set Cliente="+"'"+cliente.Text+"'"+" where ID_Cliente="+"'"+idcliente.Text+"'";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Modificado con exito");
                refrescarclientes();
                refrescardistribuidores(); 
            }
            catch (Exception errordato)
            {
                MessageBox.Show("Asegurese de que ninguno de los datos se encuentren vac�os.\nVerifique que los campos tengan los datos correctos ", "Error de datos (Modificar)");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Desea eliminar el registro del ID=" + idcliente.Text + "?", "Eliminar registro", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    con.Open();
                    OleDbCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "Delete from Tabla_Clientes where ID_Cliente=" + "'" + idcliente.Text + "'";
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Eliminacion exitosa");
                    refrescarclientes();
                } 
            }
            catch (Exception errorid)
            {
                MessageBox.Show("Asegurese de que el campo ID no se encuentre vacio.\nEl ID solo permite numeros enteros. ", "ID erroneo (Eliminar) ");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into TablaTrabajadores (ID_Trabajador, Trabajador, ID_Rol) values ('" + idtrabajador.Text + "','" + trabajador.Text + "','" + comborol + "')";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Insertado con exito");
                refrescartrabajadores();
                
            }
            catch (Exception errordato)
            {
                MessageBox.Show("Asegurese de que ninguno de los datos se encuentren vac�os.\nVerifique que los campos tengan los datos correctos ", "Error de datos insertar");

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        
            try
            {
                con.Open();
                OleDbCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into TablaProductos (ID_Producto, [ID Distribuidor], Producto, Precio, Existencias) values ('" + idproducto.Text + "','" + combodistribuidores + "','" + producto.Text + "','" + precio.Text + "','" + existencias.Text + "')";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Insertado con exito");
                
                refrescarproductos();
                refrescardistribuidores();
            }
            catch (Exception errordato)
            {
               MessageBox.Show("Asegurese de que ninguno de los datos se encuentren vac�os.\nVerifique que los campos tengan los datos correctos ", "Error de datos insertar");

            }
             
        }

        private void distribuidoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTrabajadores.Hide();
            FormProductos.Hide();
            FormClientes.Hide();
            FormDistribuidores.Show();
            
        }

        private void button16_Click(object sender, EventArgs e)
        {
            tablaDistribuidoresBindingSource.MovePrevious();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            tablaDistribuidoresBindingSource.MoveNext();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
        
        
            try
            {
                con.Open();
                OleDbCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update TablaProductos set [ID Distribuidor]=" + "'" + combodistribuidores + "'," + "Producto=" + "'" + producto.Text + "'," + "Precio=" + "'" + precio.Text + "'," + "Existencias=" + "'" + existencias.Text + "'" + " where ID_Producto=" + "'" + idproducto.Text + "'";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Modificado con exito");
                refrescarproductos();
                refrescardistribuidores();
            }
            catch (Exception errordato)
            {
                MessageBox.Show("Asegurese de que ninguno de los datos se encuentren vac�os.\nVerifique que los campos tengan los datos correctos ", "Error de datos (Modificar)");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Desea eliminar el registro del ID=" + idproducto.Text + "?", "Eliminar registro", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    con.Open();
                    OleDbCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "Delete from TablaProductos where ID_Producto=" + "'" + idproducto.Text + "'";
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Eliminacion exitosa");
                    refrescarproductos();
                    
                    
                }
            }
            catch (Exception errorid)
            {
                MessageBox.Show("Asegurese de que el campo ID no se encuentre vacio.\nEl ID solo permite numeros enteros. ", "ID erroneo (Eliminar) ");
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            a�adirdistribuidor.Hide();
            combodistribuidores = Distribuidore.SelectedValue.ToString();
            distribuidor.Text = Distribuidore.SelectedText.ToString();
            button3.Enabled=true;
            button2.Enabled=true;
        }
       
        private void button22_Click(object sender, EventArgs e)
        {
            
        }

        private void button22_Click_1(object sender, EventArgs e)
        {
            refrescardistribuidores();
            a�adirdistribuidor.Show();
        }
  
        private void Distribuidore_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button24_Click(object sender, EventArgs e)
        {
            a�adirrol.Hide();
            comborol = rolbox.SelectedValue.ToString();
            rol.Text = rolbox.SelectedText.ToString();
            button10.Enabled = true;
            button9.Enabled = true;
        }

        private void button23_Click(object sender, EventArgs e)
        {
            a�adirrol.Show();
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update TablaTrabajadores set Trabajador=" + "'" + trabajador.Text + "'," + "ID_Rol=" + "'" + comborol + "' where ID_Trabajador=" + "'" + idtrabajador.Text + "'";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Modificado con exito");
                refrescartrabajadores(); 
                refrescardistribuidores();
            }
            catch (Exception errordato)
            {
                MessageBox.Show("Asegurese de que ninguno de los datos se encuentren vac�os.\nVerifique que los campos tengan los datos correctos ", "Error de datos (Modificar)");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Desea eliminar el registro del ID=" + idtrabajador.Text + "?", "Eliminar registro", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    con.Open();
                    OleDbCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "Delete from TablaTrabajadores where ID_Trabajador=" + "'" + idtrabajador.Text + "'";
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Eliminacion exitosa");
                    refrescartrabajadores();
                }
            }
            catch (Exception errorid)
            {
                MessageBox.Show("Asegurese de que el campo ID no se encuentre vacio.\nEl ID solo permite numeros enteros. ", "ID erroneo (Eliminar) ");
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into TablaDistribuidores (ID_Distribuidor, Distribuidor) values ('" + iddistribuidor.Text + "','" + nombredistribuidor.Text + "')";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Insertado con exito");
                refrescardistribuidores();
                refrescarproductos();
            }
            catch (Exception errordato)
            {
                MessageBox.Show("Asegurese de que ninguno de los datos se encuentren vac�os.\nVerifique que los campos tengan los datos correctos ", "Error de datos insertar");

            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update TablaDistribuidores set Distribuidor=" + "'" + nombredistribuidor.Text + "'" + " where ID_Distribuidor=" + "'" + iddistribuidor.Text + "'";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Modificado con exito");
                refrescardistribuidores();
                refrescarproductos(); 
            }
            catch (Exception errordato)
            {
                MessageBox.Show("Asegurese de que ninguno de los datos se encuentren vac�os.\nVerifique que los campos tengan los datos correctos ", "Error de datos (Modificar)");
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Desea eliminar el registro del ID=" + iddistribuidor.Text + "?", "Eliminar registro", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    con.Open();
                    OleDbCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "Delete from TablaDistribuidores where ID_Distribuidor=" + "'" + iddistribuidor.Text + "'";
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Eliminacion exitosa");
                    refrescardistribuidores();
                    refrescarproductos();
                }
            }
            catch (Exception errorid)
            {
                MessageBox.Show("Asegurese de que el campo ID no se encuentre vacio.\nEl ID solo permite numeros enteros. ", "ID erroneo (Eliminar) ");
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
           
        }

       
    }
}