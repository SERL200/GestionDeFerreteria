using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
namespace WindowsApplication1
{
    public partial class Menu_Principal : Form
    {
        string guardaid = "";
        string idrol="";
        string nombre = "";
        public Menu_Principal()
        {
            InitializeComponent();
            
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\BD Ferreter�a.mdb");
        //Utilizar el de abajo (cambiar ruta)
        //OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Cris\Documents\Visual Studio 2005\Projects\GestionDeFerreteria\GestionDeFerreteria\BD Ferreter�a.mdb");
        public void identificacion()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT TablaTrabajadores.Trabajador, TablaTrabajadores.ID_Rol, TablaRoles.Rol, TablaRoles.ID_Rol FROM TablaRoles INNER JOIN TablaTrabajadores ON TablaRoles.ID_Rol = TablaTrabajadores.ID_Rol WHERE TablaTrabajadores.ID_Trabajador='" +textBox1.Text+ "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            bindingSource1.DataSource = dt;
            con.Close();
            nombre = dt.Rows[0][0].ToString();
            string rolnombre = dt.Rows[0][2].ToString();
            idrol = dt.Rows[0][3].ToString();
            string bienvenida=("Bienvenido " + nombre + "\nHas ingresado con el ID: " + textBox1.Text + "\nTu rol es: " + rolnombre);
            MessageBox.Show(bienvenida);
        }
        private void BTN_Tienda_Click(object sender, EventArgs e)
        {
            Tienda Tienda = new Tienda(guardaid);
            Tienda.ShowDialog();
        }

        private void BTN_Admin_Click(object sender, EventArgs e)
        {
            Administracion Administracion = new Administracion();
            Administracion.ShowDialog();
        }

        private void BTN_Consulta_Click(object sender, EventArgs e)
        {
            Consultas Consultas = new Consultas();
            Consultas.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                identificacion();
                if (idrol == "2")
                {
                    BTN_Admin.Enabled = true;
                    BTN_Consulta.Enabled = true;
                    BTN_Tienda.Enabled = true;
                }
                else {
                    BTN_Admin.Enabled = false;
                    BTN_Consulta.Enabled = true;
                    BTN_Tienda.Enabled = true;
                }
                guardaid = textBox1.Text;
                label2.Visible = true;
                label2.Text = "Sesi�n iniciada por: "+nombre;
                panel1.Hide();
            }
            catch {
                MessageBox.Show("Identificaci�n inv�lida, verifique sus datos");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Show();
        }

        
    }
}